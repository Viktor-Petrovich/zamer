/* Рисование бланков на canvas и упаковка в PDF без внешних библиотек.
   Геометрия повторяет form_pdf.py (единицы pt, ось Y вверх). */
(function () {
  const K = 72 / 200, PWpx = 2338, PHpx = 1653, PW = PWpx * K, PH = PHpx * K;
  const SANS = 'Arial, Roboto, "Liberation Sans", "Helvetica Neue", sans-serif';
  const SERIF = '"Times New Roman", "Liberation Serif", Georgia, serif';
  const ROW_Y = [812, 844, 880, 916, 952, 988, 1024, 1059, 1095, 1130, 1166, 1201, 1237, 1272, 1308, 1344, 1380, 1416];
  const COL = { n: [131, 254], width: [261, 362], top_A: [478, 593], top_H: [594, 709], left_H: [989, 1152], left_B: [1153, 1315],
    right_H: [1485, 1648], right_B: [1649, 1827], C: [1834, 1936], qty: [1943, 2032], color: [2039, 2163] };
  const ADDR = [124, 258, 474, 420], CONT = [124, 500, 474, 660];
  const CHOICE = { "А": [708, 217, 820, 257], "В": [1319, 217, 1430, 257] };
  const ROWS_PER_PAGE = 17;
  const X = p => p * K, Y = p => PH - p * K;
  const fmt = v => (v === null || v === undefined || v === "") ? "" : String(v).replace(".", ",");

  function newPage() {
    const c = document.createElement("canvas"); c.width = PWpx; c.height = PHpx;
    const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, PWpx, PHpx);
    x.setTransform(1 / K, 0, 0, -1 / K, 0, PHpx);
    x.fillStyle = "#000"; x.strokeStyle = "#000"; x.lineWidth = 1; x.setLineDash([]); x.lineJoin = "miter";
    return { c, x };
  }
  const fontStr = (size, bold, serif) => `${bold ? "bold " : ""}${size / K}px ${serif ? SERIF : SANS}`;
  function tw(x, s, size, bold, serif) {
    x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.font = fontStr(size, bold, serif);
    const w = x.measureText(s).width * K; x.restore(); return w;
  }
  function T(x, s, px, py, o = {}) {
    const { size = 10, bold = false, align = "left", serif = false } = o;
    x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.font = fontStr(size, bold, serif);
    x.textAlign = align; x.textBaseline = "alphabetic"; x.fillStyle = o.color || "#000";
    x.fillText(s, px / K, (PH - py) / K); x.restore();
  }
  function fit(x, s, cx, cy, maxw, size = 10.5, minsize = 5.5, bold = false) {
    while (size > minsize && tw(x, s, size, bold) > maxw) size -= 0.5;
    T(x, s, cx, cy - size * 0.35, { size, align: "center", bold });
  }
  function wrap(x, s, size, w) {
    const out = [];
    for (const para of String(s).split("\n")) {
      let line = "";
      for (const word of para.split(/\s+/)) {
        let t = line ? line + " " + word : word;
        if (tw(x, t, size) <= w) { line = t; continue; }
        if (line) out.push(line);
        line = word;
        while (tw(x, line, size) > w && line.length > 1) {
          let n = line.length - 1; while (n > 1 && tw(x, line.slice(0, n), size) > w) n--;
          out.push(line.slice(0, n)); line = line.slice(n);
        }
      }
      out.push(line);
    }
    return out;
  }
  function boxText(x, box, s, size = 11) {
    const w = (box[2] - box[0]) * K - 8, h = (box[3] - box[1]) * K - 6;
    let lines;
    for (;;) { lines = wrap(x, s, size, w); if (lines.length * size * 1.2 <= h || size <= 6) break; size -= 0.5; }
    const top = Y(box[1]) - 4 - size;
    lines.forEach((ln, i) => T(x, ln, X(box[0]) + 4, top - i * size * 1.2, { size }));
  }
  function header(x, order) {
    boxText(x, ADDR, order.address || ""); boxText(x, CONT, order.contact || "");
    const b = CHOICE[order.scheme];
    if (b) T(x, "X", X((b[0] + b[2]) / 2), Y((b[1] + b[3]) / 2) - 7, { size: 20, bold: true, align: "center" });
  }
  const line = (x, a, b, c, d) => { x.beginPath(); x.moveTo(a, b); x.lineTo(c, d); x.stroke(); };
  const tri = (x, p) => { x.beginPath(); x.moveTo(p[0][0], p[0][1]); x.lineTo(p[1][0], p[1][1]); x.lineTo(p[2][0], p[2][1]); x.closePath(); x.fill(); };
  function arrowH(x, x1, x2, y, s = 4) {
    line(x, x1, y, x2, y);
    for (const [xe, d] of [[x1, 1], [x2, -1]]) tri(x, [[xe, y], [xe + d * s * 1.8, y + s * .6], [xe + d * s * 1.8, y - s * .6]]);
  }
  function arrowV(x, px, y1, y2, s = 4) {
    line(x, px, y1, px, y2);
    for (const [ye, d] of [[y1, 1], [y2, -1]]) tri(x, [[px, ye], [px + s * .6, ye + d * s * 1.8], [px - s * .6, ye + d * s * 1.8]]);
  }
  function arrowAny(x, x1, y1, x2, y2, s = 4) {
    line(x, x1, y1, x2, y2);
    const a = Math.atan2(y2 - y1, x2 - x1);
    for (const [xe, ye, ang] of [[x1, y1, a], [x2, y2, a + Math.PI]])
      tri(x, [[xe, ye], ...[.35, -.35].map(k => [xe + s * 1.9 * Math.cos(ang + k), ye + s * 1.9 * Math.sin(ang + k)])]);
  }
  const rectS = (x, a, b, w, h) => { x.beginPath(); x.rect(a, b, w, h); x.stroke(); };

  function stampTop(x, order) {
    if (order.stamp) T(x, "Заявка от: " + order.stamp, PW - 40, PH - 22, { size: 9, align: "right", color: "#333" });
  }
  function page1(img, order, rows, start) {
    const { c, x } = newPage();
    x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.drawImage(img, 0, 0, PWpx, PHpx); x.restore();
    header(x, order); stampTop(x, order);
    const color = (order.common || {}).color;
    rows.forEach((o, i) => {
      const cy = Y((ROW_Y[i] + ROW_Y[i + 1]) / 2);
      const vals = Object.assign({}, o, { n: o.floor !== undefined ? o.floor : start + i + 1, color });
      for (const [key, [x1, x2]] of Object.entries(COL))
        fit(x, fmt(vals[key]), X((x1 + x2) / 2), cy, (x2 - x1) * K - 4, key === "color" ? 9 : 11);
    });
    const cm = order.common;
    if (cm) {
      const text = `Примечание: ширина проёма указана в графе «проём». Размеры указаны ${String(cm.bend_mode || "").toLowerCase()}, размер загиба ${fmt(cm.bend)} мм.`;
      let y = Y(1450);
      for (const ln of wrap(x, text, 9, (2163 - 131) * K)) { T(x, ln, X(131), y, { size: 9 }); y -= 11; }
    }
    return c;
  }

  function appendix(order) {
    const { c, x } = newPage(); const cm = order.common || {};
    stampTop(x, order);
    T(x, "Заявка на изготовление обрамлений ДШ. Общие параметры", PW / 2, PH - 50, { size: 14, bold: true, serif: true, align: "center" });
    T(x, "Адрес объекта: " + (order.address || ""), 40, PH - 80, { size: 10.5 });
    T(x, "Контактное лицо: " + (order.contact || ""), 40, PH - 97, { size: 10.5 });
    const noInd = String(cm.ind_floor || "").toLowerCase() === "нет табло"; const SEP = cm.btn_sep === "Да";
    const rows = [
      ["Количество остановок", order.stops],
      ["Размеры по этажам", order.dsh_same ? "одинаковые на всех этажах" : "индивидуально для каждого этажа"],
      ["Цвет окраски (RAL)", cm.color],
      ["Размеры обрамлений указаны", cm.bend_mode],
      ["Размер загиба, мм", cm.bend],
      ["Табло индикации", cm.ind_floor],
      ["Размер отверстия под табло (высота×ширина), мм", noInd ? "—" : cm.ind_size],
      ["Кнопка вызова ставится", SEP ? "отдельно стоящая (не в обрамлении)" : cm.btn_all === "Не на всех этажах" ? "на этажах: " + cm.btn_floors : "на всех этажах"],
      ["Кнопка вызова: с какой стороны", SEP ? "—" : cm.btn_side],
      ["Кнопка вызова: расстояние от пола, мм", SEP ? "—" : cm.btn_height],
      ["Размер отверстия под кнопку вызова (высота×ширина), мм", SEP ? "—" : cm.btn_size]];
    const x0 = 40, y0 = PH - 125, w1 = 380, w2 = 220, rh = 30;
    rows.forEach(([name, val], i) => {
      const y = y0 - (i + 1) * rh;
      rectS(x, x0, y, w1, rh); rectS(x, x0 + w1, y, w2, rh);
      T(x, name, x0 + 8, y + rh / 2 - 4, { size: 11 });
      fit(x, fmt(val), x0 + w1 + w2 / 2, y + rh / 2, w2 - 10, 12);
    });
    return c;
  }

  const dimLabel = (n, v) => (v !== undefined && v !== null && v !== "") ? `${n} ${fmt(v)} мм` : `${n}, мм`;
  function field(x, px, py, label, value, unit, lw = 44) {
    T(x, label, px, py, { size: 10 });
    const lx = px + tw(x, label, 10) + 4;
    x.lineWidth = .7; line(x, lx, py - 2, lx + lw, py - 2);
    if (value !== undefined && value !== null && value !== "") T(x, fmt(value), lx + lw / 2, py, { size: 10, align: "center" });
    T(x, unit, lx + lw + 4, py, { size: 10 }); x.lineWidth = 1;
  }
  function thresholdBlock(x, px, ytop, t) {
    t = t || {};
    T(x, "Пороги (рифлёнка)", px, PH - ytop, { size: 11, bold: true });
    const bx = px + 100, by = PH - (ytop + 80), bw = 190, bh = 38;
    x.lineWidth = 1.2; rectS(x, bx, by, bw, bh); x.lineWidth = .4;
    x.save(); x.beginPath(); x.rect(bx, by, bw, bh); x.clip();
    for (let k = -bh; k < bw + bh; k += 9) { line(x, bx + k, by, bx + k + bh, by + bh); line(x, bx + k, by + bh, bx + k + bh, by); }
    x.restore(); x.lineWidth = 1;
    const hy = by + 9;
    for (const hx of [bx + 12, bx + bw / 2, bx + bw - 12]) { x.fillStyle = "#fff"; x.beginPath(); x.arc(hx, hy, 3.2, 0, 7); x.fill(); x.stroke(); x.fillStyle = "#000"; }
    line(x, bx + bw - 12, hy, bx + bw - 2, by + bh + 12); line(x, bx + bw - 2, by + bh + 12, bx + bw + 12, by + bh + 12);
    T(x, "Ø6", bx + bw + 14, by + bh + 9, { size: 9 });
    x.lineWidth = .7;
    line(x, bx, by + bh + 3, bx, by + bh + 20); line(x, bx + bw, by + bh + 3, bx + bw, by + bh + 20);
    arrowH(x, bx, bx + bw - 30, by + bh + 16);
    T(x, dimLabel("Длина", t.length), bx + 4, by + bh + 21, { size: 10 });
    line(x, bx - 3, by, bx - 18, by); line(x, bx - 3, by + bh, bx - 18, by + bh);
    arrowV(x, bx - 14, by, by + bh);
    T(x, dimLabel("Ширина", t.width), bx - 20, by + bh / 2 - 4, { size: 10, align: "right" });
    x.lineWidth = 1;
    field(x, px + 100, by - 22, "Кол-во отверстий Ø6:", t.holes, "шт.", 30);
    field(x, px + 100, by - 40, "Количество:", t.qty, "шт.", 30);
  }
  function nashchBlock(x, px, ytop, t) {
    t = t || {};
    T(x, "Нащельник", px, PH - ytop, { size: 11, bold: true });
    const bx = px + 90, by = PH - (ytop + 80), bw = 190, bh = 30;
    x.lineWidth = 1.2; rectS(x, bx, by, bw, bh); x.lineWidth = .7;
    line(x, bx, by + bh + 3, bx, by + bh + 20); line(x, bx + bw, by + bh + 3, bx + bw, by + bh + 20);
    arrowH(x, bx, bx + bw, by + bh + 16);
    T(x, dimLabel("Длина", t.length), bx + bw / 2, by + bh + 21, { size: 10, align: "center" });
    line(x, bx - 3, by, bx - 18, by); line(x, bx - 3, by + bh, bx - 18, by + bh);
    arrowV(x, bx - 14, by, by + bh);
    T(x, dimLabel("Ширина", t.width), bx - 20, by + bh / 2 - 4, { size: 10, align: "right" });
    x.lineWidth = 1;
    field(x, px + 90, by - 22, "Количество:", t.qty, "шт.", 30);
  }
  function guardBlock(x, px, ytop, title, t) {
    t = t || {};
    T(x, title, px, PH - ytop, { size: 11, bold: true });
    const fw = 90, fh = 64, dx = 38, dy = 30, fx = px + 92, fy = PH - (ytop + 30) - fh - 22, bxo = fx + dx, byo = fy + dy;
    x.lineWidth = 1.4; rectS(x, fx, fy, fw, fh);
    line(x, fx, fy + fh, bxo, byo + fh); line(x, bxo, byo + fh, bxo + fw, byo + fh);
    line(x, fx + fw, fy + fh, bxo + fw, byo + fh); line(x, bxo + fw, byo + fh, bxo + fw, byo); line(x, fx + fw, fy, bxo + fw, byo);
    x.setLineDash([3, 3]); x.lineWidth = .8;
    line(x, fx, fy, bxo, byo); line(x, bxo, byo, bxo + fw, byo); line(x, bxo, byo, bxo, byo + fh);
    x.setLineDash([]); x.lineWidth = .7;
    line(x, fx - 3, fy, fx - 20, fy); line(x, fx - 3, fy + fh, fx - 20, fy + fh);
    arrowV(x, fx - 16, fy, fy + fh);
    T(x, dimLabel("Высота", t.h), fx - 22, fy + fh / 2 - 4, { size: 10, align: "right" });
    line(x, fx, fy - 3, fx, fy - 15); line(x, fx + fw, fy - 3, fx + fw, fy - 15);
    arrowH(x, fx, fx + fw, fy - 12);
    T(x, dimLabel("Ширина", t.w), fx + fw / 2, fy - 26, { size: 10, align: "center" });
    const ox = 12, oy = -12;
    arrowAny(x, fx + fw + ox, fy + oy, bxo + fw + ox, byo + oy);
    line(x, fx + fw + 2, fy - 2, fx + fw + ox, fy + oy); line(x, bxo + fw + 2, byo - 2, bxo + fw + ox, byo + oy);
    T(x, dimLabel("Длина", t.l), bxo + fw + ox + 6, byo + oy - 12, { size: 10 });
    x.lineWidth = 1;
    field(x, px + 92, fy - 46, "Количество:", t.qty, "шт.", 30);
  }
  function page2(order, thr, nsh, cable) {
    const { c, x } = newPage(), M = 30, cw = (PW - 2 * M - 18) / 2;
    frameHead(x, order, 1, 1, "Бланк замера: дополнительные элементы", "Шахта лифта: пороги, нащельники и бортики");
    const card = (cx, top) => rr(x, cx, top, cw, 200, 10, "#fff", LN, 1);
    x.strokeStyle = INKC; x.fillStyle = INKC; x.lineWidth = 1;
    if (thr) { card(M, 150); thresholdBlock(x, M + 22, 182, thr); }
    if (nsh) { card(M + cw + 18, 150); nashchBlock(x, M + cw + 18 + 22, 182, nsh); }
    if (cable?.speed_limiter) {
      card(M, 360);
      guardBlock(x, M + 22, 392, "Бортики ограничителя скорости", cable.speed_limiter);
    }
    if (cable?.main_drive) {
      card(M + cw + 18, 360);
      guardBlock(x, M + cw + 18 + 22, 392, "Бортики главного привода", cable.main_drive);
    }
    fitT(x, withComment("Все размеры в миллиметрах. На лист включены только элементы, отмеченные в заявке.", order), M, 585, PW - 2 * M, 7.5, { color: MUT });
    return c;
  }



  /* ---------- Бланк замера дверей и люков ---------- */
  const ACC = "#1b6fa8", INKC = "#15212c", MUT = "#5b6b79", LN = "#c9d3dc", SOFTC = "#f1f5f8", TINTC = "#e3eef7", AMB = "#fde3bd", AMBL = "#c9801a";
  function rr(x, px, yt, w, h, r, fill, stroke, lw) {
    x.beginPath();
    if (x.roundRect) x.roundRect(px, PH - yt - h, w, h, r); else x.rect(px, PH - yt - h, w, h);
    if (fill) { x.fillStyle = fill; x.fill(); }
    if (stroke) { x.strokeStyle = stroke; x.lineWidth = lw || 1; x.stroke(); }
  }
  const cell = (v) => (v === undefined || v === null || v === "") ? "" : fmt(v);
  const withComment = (text, order) => order.comment ? text + " Комментарий: " + order.comment : text;
  function openingDL(x, ox, yt, w, h, hatch, cas, vals) {
    const y = PH - (yt + h), t = 7;
    x.fillStyle = TINTC; x.fillRect(ox, y, w, h);
    x.save(); x.beginPath(); x.rect(ox, y, w, h); x.clip(); x.strokeStyle = "#b7cde0"; x.lineWidth = .6;
    for (let k = -h; k < w + h; k += 9) line(x, ox + k, y, ox + k + h, y + h);
    x.restore();
    x.strokeStyle = INKC; x.lineWidth = 1.8; x.strokeRect(ox, y, w, h);
    x.fillStyle = AMB; x.strokeStyle = AMBL; x.lineWidth = 1;
    const L = cas.l, Tp = cas.t, R = cas.r, B = cas.b;
    if (L) { x.fillRect(ox - t, y - (B ? t : 0), t, h + (Tp ? t : 0) + (B ? t : 0)); x.strokeRect(ox - t, y - (B ? t : 0), t, h + (Tp ? t : 0) + (B ? t : 0)); }
    if (R) { x.fillRect(ox + w, y - (B ? t : 0), t, h + (Tp ? t : 0) + (B ? t : 0)); x.strokeRect(ox + w, y - (B ? t : 0), t, h + (Tp ? t : 0) + (B ? t : 0)); }
    if (Tp) { x.fillRect(ox - (L ? t : 0), y + h, w + (L ? t : 0) + (R ? t : 0), t); x.strokeRect(ox - (L ? t : 0), y + h, w + (L ? t : 0) + (R ? t : 0), t); }
    if (B) { x.fillRect(ox - (L ? t : 0), y - t, w + (L ? t : 0) + (R ? t : 0), t); x.strokeRect(ox - (L ? t : 0), y - t, w + (L ? t : 0) + (R ? t : 0), t); }
    const hl = hatch ? true : vals.hinge !== "Справа";   // петли у люка всегда слева, напротив ручки
    x.fillStyle = INKC; x.beginPath(); x.arc(hl ? ox + w - 9 : ox + 9, y + h / 2, 2.6, 0, 7); x.fill();
    x.fillStyle = ACC; x.strokeStyle = INKC; x.lineWidth = .7;
    (hatch ? [.25, .75] : [.12, .5, .88]).forEach(k => { const hx = hl ? ox + .5 : ox + w - 5.5, hy = y + h * k - 5; x.fillRect(hx, hy, 5, 10); x.strokeRect(hx, hy, 5, 10); });
    const sx = L ? 9 : 0, by = B ? 7 : 0;
    x.strokeStyle = MUT; x.lineWidth = .6;
    line(x, ox - 4 - sx, y + h, ox - 26 - sx, y + h); line(x, ox - 4 - sx, y, ox - 26 - sx, y);
    x.strokeStyle = ACC; x.fillStyle = ACC; arrowV(x, ox - 20 - sx, y, y + h);
    x.strokeStyle = MUT; x.lineWidth = .6;
    line(x, ox, y - 4 - by, ox, y - 24 - by); line(x, ox + w, y - 4 - by, ox + w, y - 24 - by);
    x.strokeStyle = ACC; x.fillStyle = ACC; arrowH(x, ox, ox + w, y - 18 - by);
    T(x, "Высота" + (vals.h ? " " + fmt(vals.h) : ""), ox - 30 - sx, PH - yt - h / 2 - 3, { size: 10, bold: true, align: "right", color: ACC });
    T(x, "Ширина" + (vals.w ? " " + fmt(vals.w) : ""), ox + w / 2, PH - (yt + h + 33 + by), { size: 10, bold: true, align: "center", color: ACC });
  }
  function row(x, bx, yt, bw, rh, label, val, unit, hint) {
    rr(x, bx, yt, bw, rh, 6, SOFTC, LN, .8);
    T(x, label, bx + 12, PH - (yt + rh / 2 + 4), { size: label.length > 20 ? 9.5 : 10.5, bold: true, color: INKC });
    if (hint) { T(x, hint, bx + bw - 12, PH - (yt + rh / 2 + 3.5), { size: 8, align: "right", color: MUT }); return; }
    x.strokeStyle = MUT; x.lineWidth = .9; line(x, bx + 190, PH - (yt + rh - 6), bx + bw - 34, PH - (yt + rh - 6));
    if (val !== "" && val !== undefined) T(x, String(val), bx + 190 + (bw - 34 - 190) / 2, PH - (yt + rh - 9), { size: 11.5, bold: true, align: "center", color: INKC });
    T(x, unit, bx + bw - 12, PH - (yt + rh / 2 + 4), { size: 9.5, align: "right", color: MUT });
  }
  function checks(x, bx, yt, bw, rh, title, opts, on, x0, step) {
    rr(x, bx, yt, bw, rh, 6, SOFTC, LN, .8);
    T(x, title, bx + 12, PH - (yt + rh / 2 + 4), { size: 10.5, bold: true, color: INKC });
    opts.forEach(([key, lab], k) => {
      const cx = bx + x0 + k * step, cy = yt + rh / 2 - 6;
      rr(x, cx, cy, 12, 12, 2, "#fff", INKC, 1);
      if (on[key]) { x.strokeStyle = ACC; x.lineWidth = 2; x.beginPath(); x.moveTo(cx + 2.5, PH - cy - 6.5); x.lineTo(cx + 5.2, PH - cy - 9.5); x.lineTo(cx + 10, PH - cy - 2.5); x.stroke(); }
      T(x, lab, cx + 18, PH - (yt + rh / 2 + 4), { size: 10, color: INKC });
    });
  }
  let BLANK = false;
  const RED = "#c0392b";
  function resRow(x, bx, yt, bw, rh, label, text, hint) {
    rr(x, bx, yt, bw, rh, 6, "#fdecea", RED, 1.4);
    T(x, label, bx + 12, PH - (yt + rh / 2 + 4), { size: 10.5, bold: true, color: RED });
    T(x, BLANK ? "_____ × _____ мм" : text, bx + 118, PH - (yt + rh / 2 + 4.5), { size: 13, bold: true, color: RED });
    if (hint) T(x, hint, bx + bw - 12, PH - (yt + rh / 2 + 3.5), { size: 8, align: "right", color: MUT });
  }
  function dlCard(x, cx0, top, w, h, num, title, hatch, d, mult) {
    rr(x, cx0, top, w, h, 10, "#fff", LN, 1);
    x.fillStyle = ACC; x.beginPath(); x.arc(cx0 + 24, PH - (top + 24), 11, 0, 7); x.fill();
    T(x, String(num), cx0 + 24, PH - (top + 28), { size: 12, bold: true, align: "center", color: "#fff" });
    T(x, title, cx0 + 44, PH - (top + 29), { size: 15, bold: true, color: INKC });
    x.strokeStyle = LN; x.lineWidth = 1; line(x, cx0 + 14, PH - (top + 42), cx0 + w - 14, PH - (top + 42));
    if (!d || d.need !== "Да") {
      T(x, "Не требуется", cx0 + w / 2, PH - (top + h / 2 + 8), { size: 20, bold: true, align: "center", color: "#a3b0bc" });
      return;
    }
    const dw = hatch ? 76 : 54, dh = hatch ? 76 : 84;
    const cas = hatch ? { l: 1, t: 1, r: 1, b: 1 } : (BLANK ? { l: 1, t: 1, r: 1 } : { l: d.cas.l, t: d.cas.t, r: d.cas.r });
    openingDL(x, cx0 + (w - dw) / 2 + 12, top + 58, dw, dh, hatch, cas, { h: d.h, w: d.w, hinge: d.hinge });
    const bx = cx0 + 18, bw = w - 36, rh = 24, gap = 4;
    let yt = top + 58 + dh + 38 + (hatch ? 7 : 0);
    row(x, bx, yt, bw, rh, "Высота строительного проёма", cell(d.h), "мм"); yt += rh + gap;
    row(x, bx, yt, bw, rh, "Ширина строительного проёма", cell(d.w), "мм"); yt += rh + gap;
    const rh2 = hatch ? [d.h - 10, d.w - 10] : [d.h - 20, d.w - 40];
    resRow(x, bx, yt, bw, rh, hatch ? "Люк (В × Ш)" : "Дверь (В × Ш)", `${fmt(rh2[0])} × ${fmt(rh2[1])} мм`, hatch ? "проём − 10" : "В − 20, Ш − 40");
    yt += rh + gap;
    if (!hatch) { checks(x, bx, yt, bw, rh, "Петли", [["l", "слева"], ["r", "справа"]], { l: d.hinge === "Слева", r: d.hinge === "Справа" }, 118, 82); yt += rh + gap; }
    if (hatch) row(x, bx, yt, bw, rh, "Наличник", "", "", "всегда, со всех четырёх сторон");
    else checks(x, bx, yt, bw, rh, "Наличник", [["l", "слева"], ["t", "сверху"], ["r", "справа"]], BLANK ? {} : d.cas, 118, 82);
    yt += rh + gap;
    row(x, bx, yt, bw, rh, "Количество", BLANK ? "" : d.qty * mult, "шт.");
    if (mult > 1) T(x, `по ${d.qty} в каждом из ${mult} подъездов`, bx + 12, PH - (yt + rh + 11), { size: 8, color: MUT });
  }
  function dlPage(order, item) {
    const { c, x } = newPage(), M = 30;
    x.fillStyle = ACC; x.fillRect(0, PH - 6, PW, 6);
    T(x, "Бланк замера дверей и люков", M, PH - 50, { size: 22, bold: true, color: INKC });
    T(x, "Машинное помещение лифта", M, PH - 66, { size: 10, color: MUT });
    rr(x, PW - M - 170, 32, 170, 26, 13, "#e3eef7", ACC, 1);
    T(x, item.label, PW - M - 85, PH - 49, { size: 11, bold: true, align: "center", color: ACC });
    const f = (px, yt, w, label, val) => {
      x.strokeStyle = LN; x.lineWidth = .9; line(x, px, PH - yt, px + w, PH - yt);
      if (val) fitT(x, val, px + 2, yt - 4, w - 4, 11.5, { bold: true, color: INKC });
      T(x, label, px, PH - (yt + 11), { size: 8, color: MUT });
    };
    const cw = (PW - 2 * M - 40) / 3;
    f(M, 98, PW - 2 * M, "Адрес объекта", order.address);
    f(M, 128, cw + 60, "Контактное лицо на объекте, телефон", order.contact);
    f(M + cw + 80, 128, cw - 20, "Дата и время заявки", BLANK ? "" : (order.stamp || new Date().toLocaleDateString("ru-RU")));
    f(M + 2 * cw + 80, 128, PW - M - (M + 2 * cw + 80), "Замерщик", order.worker);
    const top = 150, ch = 356, cwid = (PW - 2 * M - 18) / 2;
    dlCard(x, M, top, cwid, ch, 1, "Проём двери", false, item.door, item.mult);
    dlCard(x, M + cwid + 18, top, cwid, ch, 2, "Люк", true, item.hatch, item.mult);
    fitT(x, withComment("Все размеры в миллиметрах. Размер изделия рассчитывается из строительного проёма.", order), M, 585, PW - 2 * M, 7.5, { color: MUT });
    return c;
  }

  function sashDraw(x, ox, y, w, h, kind, hinge, lw) {
    x.fillStyle = "#e8f3fb"; x.fillRect(ox, y, w, h);
    x.strokeStyle = INKC; x.lineWidth = lw || 1.2; x.strokeRect(ox, y, w, h);
    x.strokeStyle = "#9db4c6"; x.lineWidth = .6; x.strokeRect(ox + 3, y + 3, w - 6, h - 6);
    x.strokeStyle = INKC; x.lineWidth = .9; x.setLineDash([3.2, 2.2]);
    const cx = ox + w / 2, cy = y + h / 2, L = hinge !== "Справа";
    if (kind === "tr" || kind === "tt") { if (L) { line(x, ox + w, y, ox, cy); line(x, ox + w, y + h, ox, cy); } else { line(x, ox, y, ox + w, cy); line(x, ox, y + h, ox + w, cy); } }
    if (kind === "tl" || kind === "tt") { line(x, ox, y + h, cx, y); line(x, ox + w, y + h, cx, y); }
    x.setLineDash([]);
    if (kind !== "gl") { x.fillStyle = INKC; if (kind === "tl") x.fillRect(cx - 5, y + h - 10.5, 10, 3); else x.fillRect(L ? ox + w - 8.5 : ox + 5.5, cy - 5, 3, 10); }
  }
  function winCard(x, cx0, top, w, h, num, it, mult) {
    rr(x, cx0, top, w, h, 10, "#fff", LN, 1);
    x.fillStyle = ACC; x.beginPath(); x.arc(cx0 + 24, PH - (top + 24), 11, 0, 7); x.fill();
    T(x, String(num), cx0 + 24, PH - (top + 28), { size: 12, bold: true, align: "center", color: "#fff" });
    T(x, "Окно " + num, cx0 + 44, PH - (top + 29), { size: 15, bold: true, color: INKC });
    x.strokeStyle = LN; x.lineWidth = 1; line(x, cx0 + 14, PH - (top + 42), cx0 + w - 14, PH - (top + 42));
    const ww = 84, wh = 100, ox = cx0 + (w - ww) / 2 + 14, y = PH - (top + 58 + wh), f = 6;
    x.fillStyle = "#f4f6f8"; x.fillRect(ox, y, ww, wh); x.strokeStyle = INKC; x.lineWidth = 1.8; x.strokeRect(ox, y, ww, wh);
    sashDraw(x, ox + f, y + f, ww - 2 * f, wh - 2 * f, it.kind, it.hinge);
    x.strokeStyle = INKC; x.lineWidth = 1.8; x.strokeRect(ox, y, ww, wh);
    x.strokeStyle = ACC; x.fillStyle = ACC; arrowV(x, ox - 14, y, y + wh); arrowH(x, ox, ox + ww, y - 14);
    T(x, "Высота" + (it.h ? " " + fmt(it.h) : ""), ox - 22, PH - (top + 58 + wh / 2 + 3), { size: 10, bold: true, align: "right", color: ACC });
    T(x, "Ширина" + (it.w ? " " + fmt(it.w) : ""), ox + ww / 2, PH - (top + 58 + wh + 28), { size: 10, bold: true, align: "center", color: ACC });
    T(x, "Вид изнутри помещения", cx0 + w / 2, PH - (top + 58 + wh + 42), { size: 8, align: "center", color: MUT });
    const bx = cx0 + 18, bw = w - 36, rh = 24, gap = 4; let yt = top + 58 + wh + 52;
    row(x, bx, yt, bw, rh, "Высота оконного проёма", cell(it.h), "мм"); yt += rh + gap;
    row(x, bx, yt, bw, rh, "Ширина оконного проёма", cell(it.w), "мм"); yt += rh + gap;
    resRow(x, bx, yt, bw, rh, "Окно (В × Ш)", `${fmt(it.h - 20)} × ${fmt(it.w - 40)} мм`, "В − 20, Ш − 40"); yt += rh + gap;
    row(x, bx, yt, bw, rh, "Отлив (длина × ширина)", "", "", "\u200b");
    if (BLANK) T(x, "_____ × _____ мм", bx + 168, PH - (yt + rh / 2 + 4), { size: 11.5, color: MUT });
    else if (it.ebb) T(x, `${fmt(it.ebb.l)} × ${fmt(it.ebb.w)} мм`, bx + 168, PH - (yt + rh / 2 + 4), { size: 11.5, bold: true, color: ACC });
    else T(x, "не требуется", bx + 168, PH - (yt + rh / 2 + 4), { size: 10.5, color: MUT });
    yt += rh + gap;
    checks(x, bx, yt, bw, rh, "Створка", [["gl", "глухая"], ["tr", "повор."], ["tl", "откидн."], ["tt", "пов.-отк."]], BLANK ? {} : { [it.kind]: true }, 70, 72); yt += rh + gap;
    checks(x, bx, yt, bw, rh, "Петли", [["l", "слева"], ["r", "справа"]], { l: it.hinge === "Слева", r: it.hinge === "Справа" }, 118, 82); yt += rh + gap;
    row(x, bx, yt, bw, rh, "Количество", it.qty, "шт.");
  }
  function winPage(order, items, pn, pc) {
    const { c, x } = newPage(), M = 30;
    x.fillStyle = ACC; x.fillRect(0, PH - 6, PW, 6);
    T(x, "Бланк замера окон", M, PH - 50, { size: 22, bold: true, color: INKC });
    T(x, "Оконный проём и схема открывания створки", M, PH - 66, { size: 10, color: MUT });
    if (pc > 1) { rr(x, PW - M - 120, 32, 120, 26, 13, "#e3eef7", ACC, 1); T(x, `Лист ${pn} из ${pc}`, PW - M - 60, PH - 49, { size: 11, bold: true, align: "center", color: ACC }); }
    const f = (px, yt, w, label, val) => {
      x.strokeStyle = LN; x.lineWidth = .9; line(x, px, PH - yt, px + w, PH - yt);
      if (val) fitT(x, val, px + 2, yt - 4, w - 4, 11.5, { bold: true, color: INKC });
      T(x, label, px, PH - (yt + 11), { size: 8, color: MUT });
    };
    const cw = (PW - 2 * M - 40) / 3;
    f(M, 98, PW - 2 * M, "Адрес объекта", order.address);
    f(M, 128, cw + 60, "Контактное лицо на объекте, телефон", order.contact);
    f(M + cw + 80, 128, cw - 20, "Дата и время заявки", BLANK ? "" : (order.stamp || new Date().toLocaleDateString("ru-RU")));
    f(M + 2 * cw + 80, 128, PW - M - (M + 2 * cw + 80), "Замерщик", order.worker);
    const top = 150, ch = 410, cwid = (PW - 2 * M - 18) / 2;
    items.forEach((it, i) => winCard(x, M + i * (cwid + 18), top, cwid, ch, it.n, it, 1));
    fitT(x, withComment("Все размеры в миллиметрах. Размер окна рассчитывается из оконного проёма. Вид изнутри помещения.", order), M, 585, PW - 2 * M, 7.5, { color: MUT });
    return c;
  }
  /* ---------- новый бланк обрамлений ---------- */
  function boxT(x, px, yt, w, h, fill, stroke, lw) {
    const y = PH - (yt + h);
    if (fill) { x.fillStyle = fill; x.fillRect(px, y, w, h); }
    if (stroke) { x.strokeStyle = stroke; x.lineWidth = lw || 1; x.strokeRect(px, y, w, h); }
  }
  function lineT(x, a, b, c, d) { x.beginPath(); x.moveTo(a, PH - b); x.lineTo(c, PH - d); x.stroke(); }
  function fitT(x, s, px, yt, maxw, size, o = {}) {
    while (size > 5.5 && tw(x, s, size, o.bold) > maxw) size -= 0.5;
    T(x, s, px, PH - yt, Object.assign({ size }, o));
  }
  function schemeCanvas(x, ox, oy, k, cm) {   // область 200×190, масштаб f
    const A = k === "А", f = 0.66, X0 = v => ox + v * f, Y0 = v => oy + v * f;
    const R = (xx, yy, w, h, fill) => boxT(x, X0(xx), Y0(yy), w * f, h * f, fill, INKC, 1.3);
    boxT(x, X0(62), Y0(30), 76 * f, 140 * f, "#f1f5f8", null);
    const sideFill = "#cfe2f1", topFill = "#9fc3e0", leftFill = "#c6ecd5", rightFill = "#f6dcb9";
    if (A) { R(40, 56, 22, 114, leftFill); R(138, 56, 22, 114, rightFill); R(40, 30, 120, 26, topFill); }
    else { R(40, 30, 22, 140, leftFill); R(138, 30, 22, 140, rightFill); R(62, 30, 76, 26, topFill); }
    cm = cm || {};
    const noInd = String(cm.ind_floor || "").toLowerCase() === "нет табло"; const BS = cm.btn_sep === "Да" ? "" : cm.btn_side;
    if (cm.ind_floor && !noInd) {
      boxT(x, X0(84), Y0(33), 32 * f, 20 * f, "#26323c", INKC, 1);
      boxT(x, X0(87), Y0(36), 26 * f, 14 * f, "#0f171d", null);
      T(x, "табло", X0(100), PH - Y0(46), { size: 6.5, align: "center", color: "#ffb347", bold: true });
    } else T(x, "верхнее", X0(100), PH - Y0(46), { size: 8, align: "center", color: INKC });
    if (BS) {
      const left = String(BS).toLowerCase().startsWith("слева"), bx = left ? 51 : 149, by = A ? 113 : 100;
            boxT(x, X0(bx - 8), Y0(by - 8), 16 * f, 16 * f, "#e8912d", INKC, 1);
      x.fillStyle = "#fff"; x.beginPath(); x.arc(X0(bx), PH - Y0(by + 0), 3 * f, 0, 6.2832); x.fill();
      T(x, left ? "кнопка слева" : "кнопка справа", X0(100), PH - Y0(by + 3), { size: 6.5, align: "center", color: "#a85d0a", bold: true });
      x.strokeStyle = "#a85d0a"; x.lineWidth = .8; lineT(x, left ? X0(63) : X0(137), Y0(by), left ? X0(68) : X0(132), Y0(by));
    }
    [[51, "левое"], [149, "правое"]].forEach(([cx, s]) => {
      x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.translate(X0(cx + 3) / K, Y0(BS ? (A ? 78 : 62) : (A ? 113 : 100)) / K); x.rotate(-Math.PI / 2);
      x.font = fontStr(8); x.fillStyle = INKC; x.textAlign = "center"; x.fillText(s, 0, BS ? -0 : 0); x.restore();
    });
    x.strokeStyle = MUT; x.lineWidth = .6;
    if (A) { lineT(x, X0(14), Y0(30), X0(46), Y0(30)); lineT(x, X0(14), Y0(56), X0(46), Y0(56)); }
    lineT(x, X0(164), Y0(56), X0(190), Y0(56)); lineT(x, X0(164), Y0(170), X0(190), Y0(170));
    x.strokeStyle = ACC; x.fillStyle = ACC; x.lineWidth = 1;
    if (A) { arrowV(x, X0(22), PH - Y0(56), PH - Y0(30)); T(x, "A", X0(10), PH - Y0(46), { size: 11, bold: true, color: ACC, align: "center" }); }
    arrowV(x, X0(182), PH - Y0(170), PH - Y0(56)); T(x, "C", X0(194), PH - Y0(116), { size: 11, bold: true, color: ACC, align: "center" });
    x.strokeStyle = MUT; x.lineWidth = .8; x.setLineDash([5, 3]); lineT(x, X0(30), Y0(170), X0(170), Y0(170)); x.setLineDash([]);
  }
  function sectionCanvas(x, ox, oy, f) {   // область 300×244
    const X0 = v => ox + v * f, Y0 = v => oy + v * f;
    const poly = (pts, fill, stroke, lw) => { x.beginPath(); pts.forEach(([a, b], i) => { const px = X0(a), py = PH - Y0(b); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.closePath(); if (fill) { x.fillStyle = fill; x.fill(); } if (stroke) { x.strokeStyle = stroke; x.lineWidth = lw; x.lineJoin = "round"; x.stroke(); } };
    T(x, "I – I", X0(190), PH - Y0(14), { size: 11, bold: true, align: "center", color: INKC });
    x.strokeStyle = INKC; x.lineWidth = 1; lineT(x, X0(174), Y0(18), X0(206), Y0(18));
    // стена
    boxT(x, X0(150), Y0(62), 122 * f, 66 * f, TINTC, null);
    x.save(); x.beginPath(); x.rect(X0(150), PH - Y0(128), 122 * f, 66 * f); x.clip(); x.strokeStyle = "#a9c4da"; x.lineWidth = .7;
    for (let k = -70; k < 130; k += 11) lineT(x, X0(150 + k), Y0(128), X0(150 + k + 66), Y0(62));
    x.restore(); boxT(x, X0(150), Y0(62), 122 * f, 66 * f, null, INKC, 1.4);
    // рамка двери
    x.beginPath(); [[146, 26], [130, 26], [130, 62], [150, 62]].forEach(([a, b], i) => { const px = X0(a), py = PH - Y0(b); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.strokeStyle = INKC; x.lineWidth = 1.8; x.stroke();
    T(x, "Рамка двери", X0(152), PH - Y0(33), { size: 8, color: MUT });
    // профиль обрамления
    poly([[112, 26], [120, 26], [120, 182], [188, 182], [188, 134], [196, 134], [196, 190], [112, 190]], "#9fc3e0", INKC, 1.4);
    x.strokeStyle = MUT; x.lineWidth = .6;
    lineT(x, X0(76), Y0(26), X0(110), Y0(26)); lineT(x, X0(76), Y0(190), X0(110), Y0(190));
    lineT(x, X0(112), Y0(194), X0(112), Y0(222)); lineT(x, X0(196), Y0(194), X0(196), Y0(222));
    x.strokeStyle = ACC; x.fillStyle = ACC; x.lineWidth = 1;
    arrowV(x, X0(88), PH - Y0(190), PH - Y0(26)); arrowH(x, X0(112), X0(196), PH - Y0(216));
    T(x, "Н", X0(76), PH - Y0(112), { size: 11, bold: true, align: "center", color: ACC });
    T(x, "В", X0(154), PH - Y0(236), { size: 11, bold: true, align: "center", color: ACC });
  }
  function kvCell(x, px, yt, w, h, label, val) {
    rr(x, px, yt, w, h, 6, SOFTC, LN, .8);
    T(x, label, px + 10, PH - (yt + 12), { size: 8, color: MUT });
    fitT(x, BLANK ? "" : (val || "—"), px + 10, yt + 27, w - 20, 11.5, { bold: true, color: INKC });
  }
  function frameHead(x, order, pn, pc, title, sub) {
    const M = 30;
    x.fillStyle = ACC; x.fillRect(0, PH - 6, PW, 6);
    T(x, title || "Бланк замера обрамлений ДШ", M, PH - 50, { size: 22, bold: true, color: INKC });
    T(x, sub || "Шахта лифта: обрамления дверных проёмов", M, PH - 66, { size: 10, color: MUT });
    {   // логотип
      const lx = PW - M - (pc > 1 ? 120 + 190 : 190), ly = 34;
      rr(x, lx, ly, 22, 26, 3, "#d7e4ee", "#10314d", 1.2); boxT(x, lx + 3, ly + 4, 7, 19, "#8fb7d4", null); boxT(x, lx + 12, ly + 4, 7, 19, "#8fb7d4", null);
      x.strokeStyle = "#10314d"; x.lineWidth = 1; lineT(x, lx + 11, ly + 1, lx + 11, ly + 25);
      boxT(x, lx, ly - 4, 22, 3, "#c8102e", null);
      T(x, "СтройЛифтКомплекс", lx + 30, PH - (ly + 14), { size: 13.5, bold: true, color: "#10314d" });
      T(x, "замер обрамлений шахты лифта", lx + 30, PH - (ly + 26), { size: 7.5, color: MUT });
    }
    if (pc > 1) { rr(x, PW - M - 120, 32, 120, 26, 13, "#e3eef7", ACC, 1); T(x, `Лист ${pn} из ${pc}`, PW - M - 60, PH - 49, { size: 11, bold: true, align: "center", color: ACC }); }
    const f = (px, yt, w, label, val) => {
      x.strokeStyle = LN; x.lineWidth = .9; line(x, px, PH - yt, px + w, PH - yt);
      if (val) fitT(x, val, px + 2, yt - 4, w - 4, 11.5, { bold: true, color: INKC });
      T(x, label, px, PH - (yt + 11), { size: 8, color: MUT });
    };
    const cw = (PW - 2 * M - 40) / 3;
    f(M, 98, PW - 2 * M, "Адрес объекта", order.address);
    f(M, 128, cw + 60, "Контактное лицо на объекте, телефон", order.contact);
    f(M + cw + 80, 128, cw - 20, "Дата и время заявки", BLANK ? "" : (order.stamp || new Date().toLocaleDateString("ru-RU")));
    f(M + 2 * cw + 80, 128, PW - M - (M + 2 * cw + 80), "Замерщик", order.worker);
  }
  function frameTable(x, order, rows, ytop, maxRows) {
    const M = 30, cols = [["Этаж", 56], ["Проём", 76], ["А", 72], ["Н", 72], ["Н", 72], ["В", 72], ["Н", 72], ["В", 72], ["С", 76], ["Кол-во", 60], ["Цвет", 82]];
    const groups = [[2, 2, "Верхнее обрамление"], [4, 2, "Левое боковое"], [6, 2, "Правое боковое"]];
    const xs = []; let ax = M; cols.forEach(c => { xs.push(ax); ax += c[1]; });
    const hh = 17;
    // шапка
    boxT(x, M, ytop, ax - M, hh * 2, ACC, null);
    x.strokeStyle = "rgba(255,255,255,.55)"; x.lineWidth = .8;
    const gcol = ["#6fb0e3", "#5cc08a", "#f0a24a"];
    groups.forEach(([i, n, t], gi) => { boxT(x, xs[i], ytop, cols[i][1] * n, 3.2, gcol[gi], null); T(x, t, xs[i] + (cols[i][1] * n) / 2, PH - (ytop + 12), { size: 9, bold: true, color: "#fff", align: "center" }); lineT(x, xs[i], ytop, xs[i], ytop + hh * 2); lineT(x, xs[i], ytop + hh, xs[i] + cols[i][1] * n, ytop + hh); });
    cols.forEach(([t, w], i) => {
      const g = groups.some(([gi, n]) => i >= gi && i < gi + n);
      const lab = g ? t : t;
      T(x, lab, xs[i] + w / 2, PH - (ytop + (g ? hh + 12 : hh + 4)), { size: 9, bold: true, color: "#fff", align: "center" });
      if (i) { x.strokeStyle = "rgba(255,255,255,.35)"; lineT(x, xs[i], g ? ytop + hh : ytop, xs[i], ytop + hh * 2); }
    });
    const rh = 17, cm = order.common || {};
    for (let r = 0; r < maxRows; r++) {
      const o = rows[r], yt = ytop + hh * 2 + r * rh;
      boxT(x, M, yt, ax - M, rh, r % 2 ? "#f6f9fb" : "#ffffff", null);
      x.strokeStyle = LN; x.lineWidth = .6; lineT(x, M, yt + rh, ax, yt + rh);
      if (!o) continue;
      const vals = [o.floor !== undefined && o.floor !== "" ? "Этаж " + o.floor : "", o.width, o.top_A, o.top_H, o.left_H, o.left_B, o.right_H, o.right_B, o.C, o.qty, cm.color];
      vals.forEach((v, i) => { if (v !== undefined && v !== "") fitT(x, fmt(v), xs[i] + cols[i][1] / 2 - tw(x, fmt(v), 10.5, i === 0) / 2, yt + 12, cols[i][1] - 6, 10.5, { bold: i === 0, color: INKC }); });
    }
    x.strokeStyle = LN; x.lineWidth = 1; x.strokeRect(M, PH - (ytop + hh * 2 + maxRows * rh), ax - M, hh * 2 + maxRows * rh);
    x.strokeStyle = LN; x.lineWidth = .6; xs.forEach((px, i) => { if (i) lineT(x, px, ytop + hh * 2, px, ytop + hh * 2 + maxRows * rh); });
  }
  function framePages(order) {
    const rows = order.openings || [], cm = order.common || {}, M = 30, FIRST = 12, NEXT = 22;
    const pc = rows.length <= FIRST ? 1 : 1 + Math.ceil((rows.length - FIRST) / NEXT), pages = [];
    for (let pn = 1; pn <= pc; pn++) {
      const { c, x } = newPage(); frameHead(x, order, pn, pc);
      let top = 150, part, maxRows;
      if (pn === 1) {
        part = rows.slice(0, FIRST); maxRows = FIRST;
        const ch = 180, w1 = BLANK ? 330 : 250; rr(x, M, top, w1, ch, 10, "#fff", LN, 1);
        T(x, BLANK ? "Схема обрамления (отметьте А или В)" : "Схема обрамления " + (order.scheme || ""), M + 14, PH - (top + 24), { size: 12, bold: true, color: INKC });
        if (BLANK) ["А", "В"].forEach((k, i) => { const sx = M + 14 + i * 158; schemeCanvas(x, sx, top + 36, k); x.strokeStyle = INKC; x.lineWidth = 1.2; x.strokeRect(sx + 4, PH - (top + 168), 12, 12); T(x, "Схема " + k, sx + 22, PH - (top + 167), { size: 10, bold: true, color: INKC }); });
        else schemeCanvas(x, M + (w1 - 132) / 2, top + 36, order.scheme === "В" ? "В" : "А", cm);
        const cx0 = M + w1 + 12, cw2 = PW - M - cx0;
        rr(x, cx0, top, cw2, ch, 10, "#fff", LN, 1);
        T(x, "Общие параметры", cx0 + 14, PH - (top + 24), { size: 12, bold: true, color: INKC });
        const noInd = String(cm.ind_floor || "").toLowerCase() === "нет табло";
        const btn = cm.btn_sep === "Да" ? "отдельно стоящая (не в обрамлении)" : [cm.btn_all === "Не на всех этажах" ? "этажи " + cm.btn_floors : "на всех этажах", cm.btn_side && cm.btn_side.toLowerCase(), cm.btn_height ? cm.btn_height + " мм от пола" : "", cm.btn_size ? "отв. " + cm.btn_size : ""].filter(Boolean).join(", ");
        const cells = [["Табло", noInd ? "нет табло" : `${cm.ind_floor || ""}${cm.ind_size ? ", отв. " + cm.ind_size + " мм" : ""}`],
          ["Размеры", `${cm.bend_mode || ""}${cm.bend !== undefined && cm.bend !== "" ? ", загиб " + fmt(cm.bend) + " мм" : ""}`],
          ["Кнопка вызова", btn], ["Цвет окраски", cm.color],
          ["Портал (В × Ш)", cm.portal_size], ["Остановок", order.stops ? order.stops + " эт." : ""], ["По этажам", BLANK ? "" : (order.dsh_same ? "одинаковые на всех этажах" : "подписать поэтажно")]];
        cells.forEach(([l, v], i) => { const yt = top + 36 + i * 20; rr(x, cx0 + 12, yt, cw2 - 24, 18, 5, SOFTC, LN, .7);
          T(x, l, cx0 + 20, PH - (yt + 13), { size: 8, color: MUT });
          if (BLANK) { x.strokeStyle = LN; x.lineWidth = .9; line(x, cx0 + 92, PH - (yt + 15), cx0 + cw2 - 20, PH - (yt + 15)); } else fitT(x, v || "—", cx0 + 20 + 70, yt + 14, cw2 - 24 - 70 - 14, 10, { bold: true, color: INKC }); });
        top += ch + 10;
      } else { part = rows.slice(FIRST + (pn - 2) * NEXT, FIRST + (pn - 1) * NEXT); maxRows = NEXT; }
      frameTable(x, order, part, top, maxRows);
      const note = `Все размеры в миллиметрах. ${order.dsh_same ? "Размеры одинаковые на всех этажах." : "Размеры указаны для каждого этажа отдельно (поэтажно)."} Ширина проёма указана в графе «Проём». ${cm.bend_mode ? "Размеры указаны " + String(cm.bend_mode).toLowerCase() + (cm.bend ? ", размер загиба " + fmt(cm.bend) + " мм" : "") + "." : ""}`;
      fitT(x, withComment(note, order), M, 585, PW - 2 * M, 7.5, { color: MUT });
      pages.push(c);
    }
    return pages;
  }
  const loadImg = src => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = src; });

  async function buildPages(order) {
    return buildPages0(order);
  }
  async function buildPages0(order) {
    if (order.kind === "dl") return order.items.map(it => dlPage(order, it));
    if (order.kind === "win") { const pc = Math.max(1, Math.ceil(order.items.length / 2)); return Array.from({ length: pc }, (_, i) => winPage(order, order.items.slice(i * 2, i * 2 + 2), i + 1, pc)); }
    const pages = [], ops = order.openings || [];
    const thr = order.thresholds || [], nsh = order.nashchelnik || [];
    const cable = order.cable && Object.keys(order.cable).length ? order.cable : null;
    if (ops.length || !(thr.length || nsh.length || cable)) pages.push(...framePages(order));
    const n = Math.max(thr.length, nsh.length, cable ? 1 : 0);
    for (let i = 0; i < n; i++) pages.push(page2(order, thr[i], nsh[i], i === 0 ? cable : null));
    return pages;
  }

  /* --- минимальный писатель PDF: каждая страница — JPEG --- */
  function dataUrlToBytes(u) { const b = atob(u.split(",")[1]); const a = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function makePdf(canvases, title, data) {
    const enc = new TextEncoder(), parts = [], offs = []; let len = 0;
    const add = d => { const u = typeof d === "string" ? enc.encode(d) : d; parts.push(u); len += u.length; };
    const obj = (n, body) => { offs[n] = len; add(`${n} 0 obj\n`); add(body); add("\nendobj\n"); };
    const N = canvases.length, W = PW.toFixed(2), H = PH.toFixed(2);
    add("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
    const infoN = 3 + N * 3, hex16 = str => "FEFF" + Array.from(str || "").map(ch => { const c = ch.codePointAt(0); if (c > 0xFFFF) { const h = 0xD800 + ((c - 0x10000) >> 10), l = 0xDC00 + ((c - 0x10000) & 0x3FF); return h.toString(16).padStart(4, "0") + l.toString(16).padStart(4, "0"); } return c.toString(16).padStart(4, "0"); }).join("").toUpperCase();
    const json = data ? JSON.stringify(data) : "", jb = enc.encode(json), efN = infoN + 1, fsN = infoN + 2;
    obj(1, data ? `<< /Type /Catalog /Pages 2 0 R /Names << /EmbeddedFiles << /Names [(zamer.json) ${fsN} 0 R] >> >> /AF [${fsN} 0 R] >>` : "<< /Type /Catalog /Pages 2 0 R >>");
    obj(2, `<< /Type /Pages /Count ${N} /Kids [${canvases.map((_, i) => `${3 + i * 3} 0 R`).join(" ")}] >>`);
    canvases.forEach((cv, i) => {
      const p = 3 + i * 3, jpg = dataUrlToBytes(cv.toDataURL("image/jpeg", 0.92));
      obj(p, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 ${p + 1} 0 R >> >> /Contents ${p + 2} 0 R >>`);
      offs[p + 1] = len; add(`${p + 1} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpg.length} >>\nstream\n`);
      add(jpg); add("\nendstream\nendobj\n");
      const cs = `q ${W} 0 0 ${H} 0 0 cm /Im0 Do Q`;
      obj(p + 2, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
    });
    const meta = data ? ` /Keywords <${hex16((data.city || "") + "; " + (data.kind || ""))}> /ZamerData <${hex16(json)}>` : "";
    obj(infoN, `<< /Title <${hex16(title || "")}>${meta} >>`);
    let last = infoN;
    if (data) {
      offs[efN] = len; add(`${efN} 0 obj\n<< /Type /EmbeddedFile /Subtype /application#2Fjson /Length ${jb.length} >>\nstream\n`); add(jb); add("\nendstream\nendobj\n");
      obj(fsN, `<< /Type /Filespec /F (zamer.json) /UF (zamer.json) /AFRelationship /Data /EF << /F ${efN} 0 R >> >>`);
      last = fsN;
    }
    const xref = len; add(`xref\n0 ${last + 1}\n0000000000 65535 f \n`);
    for (let i = 1; i <= last; i++) add(String(offs[i]).padStart(10, "0") + " 00000 n \n");
    add(`trailer\n<< /Size ${last + 1} /Root 1 0 R /Info ${infoN} 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(parts, { type: "application/pdf" });
  }

  window.PDFGEN = { buildPages, makePdf, setBlank: v => { BLANK = !!v; } };
})();

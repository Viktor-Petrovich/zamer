(() => {
  "use strict";

  const STORAGE_KEY = "zamer-unified-mockup-v1";
  const TYPE_META = {
    frame: { name: "Обрамления", icon: "panel-top", section: "Общие параметры" },
    door: { name: "Двери и люки", icon: "door-open", section: "Двери и люки" },
    window: { name: "Окна", icon: "panels-top-left", section: "Размеры окон" }
  };
  const emptyFloor = () => ({ topA: "", topH: "", leftH: "", leftB: "", rightH: "", rightB: "" });
  const sampleFloor = () => ({ topA: "180", topH: "120", leftH: "120", leftB: "90", rightH: "120", rightB: "90" });
  const blankThreshold = () => ({ length: "", width: "", holes: "0", qty: "1" });
  const blankNashchelnik = () => ({ length: "", width: "", qty: "1" });
  const blankBortik = () => ({ h: "", w: "", l: "", qty: "1" });
  const makeData = (sample = false) => ({
    type: "frame",
    address: sample ? "г. Казань, ул. Мира, 3" : "",
    contact: sample ? "Иван, +7 900 123-45-67" : "",
    entrances: 1,
    stops: 9,
    comment: "",
    frame: {
      width: sample ? "900" : "", portalH: sample ? "2100" : "", portalW: sample ? "1000" : "",
      scheme: "А", color: "Белый, RAL 9003", same: true,
      displayOn: true, displayLocation: "На всех этажах", displayFloors: null, displayH: sample ? "80" : "", displayW: sample ? "120" : "",
      bendMode: "С учётом загиба", bend: sample ? "20" : "",
      buttonSeparate: false, buttonAll: "На всех этажах", buttonFloors: "", buttonSide: "Слева", buttonHeight: sample ? "1100" : "", buttonH: sample ? "30" : "", buttonW: sample ? "30" : "",
      floors: [sample ? sampleFloor() : emptyFloor()],
      thresholdsOn: false, nashchelnikOn: false, bortikiOn: false,
      thresholds: [],
      nashchelnik: [],
      cable: {
        speed_limiter: null,
        main_drive: null
      }
    },
    door: {
      needDoor: true, needHatch: true,
      doorH: "2000", doorW: "800", doorQty: "1", hinge: "Петли справа",
      casingLeft: true, casingTop: true, casingRight: true,
      hatchH: "600", hatchW: "600", hatchQty: "1"
    },
    window: {
      items: [{ id: 1, kind: "Поворотное", h: "1200", w: "800", qty: "1", hinge: "Петли справа", ebb: true, ebbL: "1250", ebbW: "150" }]
    }
  });

  const templates = [
    {
      id: "residential", type: "frame", title: "Типовой жилой дом", description: "Обрамления · 9 этажей · одинаковые размеры", meta: "12 полей",
      data: makeData(true)
    },
    {
      id: "doors", type: "door", title: "Дверь и люк в подъезд", description: "Один подъезд · дверь 2000 × 800 · люк 600 × 600", meta: "8 полей",
      data: { ...makeData(false), type: "door", address: "", entrances: 1, stops: 1 }
    },
    {
      id: "windows", type: "window", title: "Окна в лифтовом холле", description: "Два поворотных окна · с отливами · петли справа", meta: "10 полей",
      data: { ...makeData(false), type: "window", address: "", stops: 2, window: { items: [
        { id: 1, kind: "Поворотное", h: "1200", w: "800", qty: "1", hinge: "Петли справа", ebb: true, ebbL: "1250", ebbW: "150" },
        { id: 2, kind: "Поворотное", h: "1200", w: "800", qty: "1", hinge: "Петли справа", ebb: true, ebbL: "1250", ebbW: "150" }
      ] } }
    }
  ];

  const initialRequests = [
    { id: "ДШ-1047", owner: "Алексей Петров", date: "Сегодня, 09:42", status: "Синхронизировано", data: { ...makeData(true), address: "г. Казань, ул. Пушкина, 10", stops: 5 } },
    { id: "ДШ-1042", owner: "Алексей Петров", date: "21 нояб., 16:18", status: "Синхронизировано", data: { ...makeData(false), type: "door", address: "г. Казань, ул. Четаева, 35", stops: 1 } },
    { id: "ДШ-1038", owner: "Алексей Петров", date: "20 нояб., 11:05", status: "Синхронизировано", data: { ...makeData(false), type: "window", address: "г. Набережные Челны, пр. Набережночелнинский, 24", stops: 2 } },
    { id: "ДШ-1046", owner: "Мария Волкова", date: "Вчера, 15:26", status: "Синхронизировано", data: { ...makeData(true), address: "г. Казань, ул. Гарифьянова, 12", stops: 10 } }
  ];

  let restored = null;
  try { restored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null"); } catch (_) { /* demo starts cleanly */ }
  const state = {
    data: normalizeData(restored?.data || makeData(true)),
    role: restored?.role === "manager" ? "manager" : "surveyor",
    demoOffline: false,
    queue: Array.isArray(restored?.queue) ? restored.queue : [],
    requests: Array.isArray(restored?.requests) && restored.requests.length ? restored.requests : initialRequests,
    draftId: restored?.draftId || "ДШ-1048",
    nextWindowId: 10,
    saveTimer: null,
    toastTimer: null,
    dialogView: null,
    lastFocus: null,
    pdfBusy: false,
    displayFloorDraft: null
  };

  if (!["А", "В"].includes(state.data.frame?.scheme)) state.data.frame.scheme = "А";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  const clone = value => JSON.parse(JSON.stringify(value));
  function normalizeData(data) {
    const base = makeData(false);
    const result = { ...base, ...data, frame: { ...base.frame, ...(data?.frame || {}) }, door: { ...base.door, ...(data?.door || {}) }, window: { ...base.window, ...(data?.window || {}) } };
    if (!Array.isArray(result.frame.thresholds)) result.frame.thresholds = result.frame.thresholds === true ? [blankThreshold()] : [];
    if (!Array.isArray(result.frame.nashchelnik)) result.frame.nashchelnik = result.frame.nashchelnik === true ? [blankNashchelnik()] : [];
    if (!result.frame.cable || typeof result.frame.cable !== "object") result.frame.cable = { speed_limiter: null, main_drive: null };
    if (data?.frame?.bortiki === true && !result.frame.cable.speed_limiter && !result.frame.cable.main_drive) result.frame.cable = { speed_limiter: blankBortik(), main_drive: blankBortik() };
    if (data?.frame?.thresholdsOn === undefined) result.frame.thresholdsOn = result.frame.thresholds.length > 0;
    if (data?.frame?.nashchelnikOn === undefined) result.frame.nashchelnikOn = result.frame.nashchelnik.length > 0;
    if (data?.frame?.bortikiOn === undefined) result.frame.bortikiOn = !!(result.frame.cable.speed_limiter || result.frame.cable.main_drive);
    if (data?.frame?.displayFloors === undefined) result.frame.displayFloors = result.frame.displayLocation === "Только на 1 этаже" ? [1] : null;
    if (result.frame.displayFloors !== null && !Array.isArray(result.frame.displayFloors)) result.frame.displayFloors = null;
    return result;
  }
  const icons = () => window.lucide?.createIcons({ attrs: { "aria-hidden": "true" } });
  const getPath = (object, path) => path.split(".").reduce((value, key) => value?.[key], object);
  const setPath = (object, path, value) => {
    const keys = path.split("."), last = keys.pop();
    const parent = keys.reduce((item, key) => item[key], object);
    parent[last] = value;
  };
  const inputValue = (path, attrs = "") => `<span class="input-wrap unit-input" data-unit="мм"><input type="text" inputmode="decimal" data-bind="${path}" value="${esc(getPath(state.data, path))}" ${attrs}></span>`;
  const textInput = (path, attrs = "") => `<span class="input-wrap"><input type="text" data-bind="${path}" value="${esc(getPath(state.data, path))}" ${attrs}></span>`;
  const unitValue = (path, unit = "шт.", attrs = "") => `<span class="input-wrap unit-input" data-unit="${unit}"><input type="text" inputmode="numeric" data-bind="${path}" value="${esc(getPath(state.data, path))}" ${attrs}></span>`;
  const switchControl = (path, label) => `<button class="switch" type="button" role="switch" aria-checked="${!!getPath(state.data, path)}" aria-label="${esc(label)}" data-toggle="${path}"></button>`;

  function ensureFloors() {
    const floors = state.data.frame.floors;
    const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
    if (!Array.isArray(floors) || !floors.length) state.data.frame.floors = [emptyFloor()];
    while (state.data.frame.floors.length < count) state.data.frame.floors.push(emptyFloor());
    if (Array.isArray(state.data.frame.displayFloors)) {
      const selected = displayFloorSelection();
      state.data.frame.displayFloors = selected.length === count ? null : selected;
    }
    syncDisplayLocation();
  }

  function displayFloorSelection(data = state.data) {
    const count = Math.max(1, Math.min(30, Number(data.stops) || 1));
    if (data.frame.displayFloors === null || data.frame.displayFloors === undefined) return Array.from({ length: count }, (_, index) => index + 1);
    return [...new Set(data.frame.displayFloors.map(Number).filter(floor => Number.isInteger(floor) && floor >= 1 && floor <= count))].sort((a, b) => a - b);
  }

  function floorRanges(floors) {
    const ranges = [];
    for (let index = 0; index < floors.length; index++) {
      const start = floors[index];
      let end = start;
      while (index + 1 < floors.length && floors[index + 1] === end + 1) end = floors[++index];
      ranges.push(start === end ? String(start) : `${start}–${end}`);
    }
    return ranges.join(", ");
  }

  function displayFloorLabel(data = state.data) {
    const count = Math.max(1, Math.min(30, Number(data.stops) || 1));
    const selected = displayFloorSelection(data);
    if (!selected.length) return "Этажи не выбраны";
    if (selected.length === count) return "На всех этажах";
    return `Этажи: ${floorRanges(selected)}`;
  }

  function syncDisplayLocation() {
    const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
    const selected = displayFloorSelection();
    state.data.frame.displayLocation = selected.length === count ? "На всех этажах" : selected.length === 1 && selected[0] === 1 ? "Только на 1 этаже" : "Выбранные этажи";
  }

  function showDisplayFloors() {
    const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
    state.displayFloorDraft = displayFloorSelection();
    openDialog("display-floors", "Табло индикации", "На каких этажах нужно табло", `<p class="dialog-description">Отметьте этажи, где требуется табло. На снятых этажах оно не понадобится.</p><div class="display-floor-actions"><button class="button button-secondary" type="button" data-display-select="all">Выбрать все</button><button class="button button-secondary" type="button" data-display-select="none">Снять все</button></div><p class="display-floor-count" id="display-floor-count"></p><div class="display-floor-grid">${Array.from({ length: count }, (_, index) => index + 1).map(floor => `<label class="display-floor-option"><input type="checkbox" data-display-floor="${floor}"><span>${floor}-й этаж</span></label>`).join("")}</div><div class="confirm-actions"><button class="button button-secondary" type="button" data-dialog-close>Отмена</button><button class="button button-primary" type="button" data-action="apply-display-floors"><i data-lucide="check"></i>Готово</button></div>`);
    refreshDisplayFloorDialog();
  }

  function refreshDisplayFloorDialog() {
    const selected = state.displayFloorDraft || [];
    $$('[data-display-floor]').forEach(input => { input.checked = selected.includes(Number(input.dataset.displayFloor)); });
    const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
    const label = selected.length === count ? `Выбраны все этажи: ${count}` : `Выбрано этажей: ${selected.length} из ${count}`;
    if ($("#display-floor-count")) $("#display-floor-count").textContent = label;
  }

  function applyDisplayFloors() {
    const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
    const selected = [...new Set((state.displayFloorDraft || []).filter(floor => floor >= 1 && floor <= count))].sort((a, b) => a - b);
    state.data.frame.displayFloors = selected.length === count ? null : selected;
    syncDisplayLocation();
    state.displayFloorDraft = null;
    closeDialog();
    renderTypeFields();
    clearErrors();
    touch();
    $("[data-action=\"display-floors\"]")?.focus({ preventScroll: true });
    showToast("Этажи для табло сохранены", "check");
  }

  function dimensionCell(title, letter, firstPath, secondPath, firstLabel, secondLabel) {
    return `<div class="dimension-cell"><div class="dimension-cell-title"><b>${letter}</b><span>${title}</span></div><div class="dimension-inputs">${inputValue(firstPath, `aria-label="${firstLabel}" placeholder="${firstLabel}"`)}${inputValue(secondPath, `aria-label="${secondLabel}" placeholder="${secondLabel}"`)}</div></div>`;
  }

  function floorRow(floor, index, shared) {
    const base = `frame.floors.${index}`;
    const title = shared ? "Единый размер" : `${index + 1}-й этаж`;
    const subtitle = shared ? `Применится ко всем этажам: ${state.data.stops}` : `Этаж ${index + 1} из ${state.data.stops}`;
    return `<div class="floor-row"><div class="floor-row-title"><strong>${title}</strong><span>${subtitle}</span></div><div class="floor-dimensions">
      ${dimensionCell("Верхнее", "А / Н", `${base}.topA`, `${base}.topH`, "А, высота", "Н, глубина")}
      ${dimensionCell("Левое боковое", "Н / В", `${base}.leftH`, `${base}.leftB`, "Н, глубина", "В, ширина")}
      ${dimensionCell("Правое боковое", "Н / В", `${base}.rightH`, `${base}.rightB`, "Н, глубина", "В, ширина")}
    </div></div>`;
  }

  function techDefs(id) {
    return `<defs><marker id="${id}-arrow" viewBox="0 0 6 6" refX="3" refY="3" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L6 3L0 6z" class="tech-arrow"/></marker><pattern id="${id}-hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" class="tech-hatch"/></pattern></defs>`;
  }

  function techDimension(id, x1, y1, x2, y2, tx, ty, label, rotate = false) {
    return `<line class="tech-dimension" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-start="url(#${id}-arrow)" marker-end="url(#${id}-arrow)"/><text class="tech-dimension-label" x="${tx}" y="${ty}" text-anchor="middle"${rotate ? ` transform="rotate(-90 ${tx} ${ty})"` : ""}>${label}</text>`;
  }

  function schemeSvg(kind, uid = `scheme-${kind}`) {
    const isA = kind === "А";
    const side = (x, y, h, label) => `<rect class="tech-part" x="${x}" y="${y}" width="22" height="${h}" rx="2"/><text class="tech-part-label" transform="translate(${x + 14} ${y + h / 2}) rotate(-90)" text-anchor="middle">${label}</text>`;
    const top = isA
      ? '<rect class="tech-part tech-part-top" x="40" y="28" width="120" height="26" rx="2"/><text class="tech-part-label" x="100" y="45" text-anchor="middle">верхнее</text>'
      : '<rect class="tech-part tech-part-top" x="62" y="28" width="76" height="26" rx="2"/><text class="tech-part-label" x="100" y="45" text-anchor="middle">верхнее</text>';
    const sides = isA ? side(40, 54, 112, "левое") + side(138, 54, 112, "правое") : side(40, 28, 138, "левое") + side(138, 28, 138, "правое");
    return `<svg class="technical-svg scheme-svg" viewBox="0 0 200 188" role="img" aria-label="Схема ${kind}: ${isA ? "верхнее обрамление накрывает боковые" : "верхнее обрамление между боковыми"}">${techDefs(uid)}<rect x="62" y="28" width="76" height="138" class="tech-gap"/>${sides}${top}${isA ? techDimension(uid, 20, 28, 20, 54, 12, 44, "А") : ""}<line x1="30" y1="166" x2="170" y2="166" class="tech-floor"/></svg>`;
  }

  function sectionSvg(uid = "section") {
    return `<svg class="technical-svg section-svg" viewBox="0 0 300 244" role="img" aria-label="Сечение бокового обрамления: Н — глубина, В — ширина">${techDefs(uid)}<text x="190" y="14" text-anchor="middle" class="tech-note">I – I</text><line x1="174" y1="18" x2="206" y2="18" class="tech-outline"/><rect x="150" y="62" width="122" height="66" class="tech-opening"/><rect x="150" y="62" width="122" height="66" fill="url(#${uid}-hatch)"/><rect x="150" y="62" width="122" height="66" class="tech-outline-fill"/><path d="M146 26 H130 V62 H150" class="tech-profile-line"/><text x="152" y="38" class="tech-note">Рамка двери</text><path d="M112 26 H120 V182 H188 V134 H196 V190 H112 Z" class="tech-profile"/><line x1="76" y1="26" x2="110" y2="26" class="tech-extension"/><line x1="76" y1="190" x2="110" y2="190" class="tech-extension"/>${techDimension(uid, 88, 26, 88, 190, 76, 112, "Н", true)}<line x1="112" y1="194" x2="112" y2="222" class="tech-extension"/><line x1="196" y1="194" x2="196" y2="222" class="tech-extension"/>${techDimension(uid, 112, 216, 196, 216, 154, 236, "В")}</svg>`;
  }

  function doorSvg(casing, hinge, uid = "door") {
    const right = hinge === "Петли справа";
    const casingPart = (enabled, x, y, w, h, tx, ty) => `<g class="tech-casing ${enabled ? "enabled" : ""}"><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4"/><text x="${tx}" y="${ty}" text-anchor="middle">${enabled ? "✓" : "+"}</text></g>`;
    return `<svg class="technical-svg door-svg" viewBox="0 0 260 250" role="img" aria-label="Дверь: высота и ширина проёма, наличники и петли">${techDefs(uid)}<rect x="96" y="70" width="76" height="150" class="tech-opening"/><rect x="96" y="70" width="76" height="150" fill="url(#${uid}-hatch)"/><rect x="96" y="70" width="76" height="150" class="tech-leaf"/><circle class="tech-handle" cx="${right ? 106 : 162}" cy="148" r="3.6"/><g>${[92,138,192].map(y => `<rect x="${right ? 165 : 96}" y="${y}" width="7" height="16" rx="1.5" class="tech-hinge"/>`).join("")}</g><line x1="50" y1="220" x2="218" y2="220" class="tech-floor"/>${casingPart(casing.left,68,44,28,176,82,136)}${casingPart(casing.top,96,44,76,26,134,62)}${casingPart(casing.right,172,44,28,176,186,136)}${techDimension(uid,46,70,46,220,36,145,"Высота",true)}${techDimension(uid,96,28,172,28,134,19,"Ширина")}<text x="134" y="240" text-anchor="middle" class="tech-note">пол</text></svg>`;
  }

  function hatchSvg(uid = "hatch") {
    return `<svg class="technical-svg hatch-svg" viewBox="0 0 260 230" role="img" aria-label="Люк: высота и ширина проёма">${techDefs(uid)}<rect x="78" y="52" width="104" height="104" class="tech-casing enabled"/><rect x="94" y="68" width="72" height="72" class="tech-opening"/><rect x="94" y="68" width="72" height="72" fill="url(#${uid}-hatch)"/><rect x="94" y="68" width="72" height="72" class="tech-leaf"/><circle cx="154" cy="104" r="3.6" class="tech-handle"/>${[78,116].map(y => `<rect x="94" y="${y}" width="7" height="16" rx="1.5" class="tech-hinge"/>`).join("")}${techDimension(uid,54,68,54,140,44,104,"Высота",true)}${techDimension(uid,94,176,166,176,130,196,"Ширина")}<text x="130" y="214" text-anchor="middle" class="tech-note">наличник со всех сторон</text></svg>`;
  }

  function thresholdSvg(uid = "threshold") {
    return `<svg class="technical-svg threshold-svg" viewBox="0 0 300 190" role="img" aria-label="Порог: длина, ширина и отверстия диаметром 6 мм">${techDefs(uid)}<rect x="65" y="48" width="170" height="58" class="tech-opening"/><rect x="65" y="48" width="170" height="58" fill="url(#${uid}-hatch)"/><rect x="65" y="48" width="170" height="58" class="tech-leaf"/>${[88,150,212].map(x => `<circle cx="${x}" cy="66" r="4" class="tech-threshold-hole"/>`).join("")}<path d="M216 66 H242 V86" class="tech-profile-line"/><text x="247" y="91" class="tech-note">Ø6</text><line x1="65" y1="110" x2="65" y2="143" class="tech-extension"/><line x1="235" y1="110" x2="235" y2="143" class="tech-extension"/>${techDimension(uid,65,137,235,137,150,157,"Длина")}${techDimension(uid,43,48,43,106,31,77,"Ширина",true)}</svg>`;
  }

  function nashchelnikSvg(uid = "nashchelnik") {
    return `<svg class="technical-svg nashchelnik-svg" viewBox="0 0 300 190" role="img" aria-label="Нащельник: длина и ширина">${techDefs(uid)}<rect x="65" y="58" width="170" height="42" class="tech-part"/><line x1="65" y1="104" x2="65" y2="137" class="tech-extension"/><line x1="235" y1="104" x2="235" y2="137" class="tech-extension"/>${techDimension(uid,65,131,235,131,150,151,"Длина")}${techDimension(uid,43,58,43,100,31,79,"Ширина",true)}</svg>`;
  }

  function bortikSvg(uid = "bortik") {
    return `<svg class="technical-svg bortik-svg" viewBox="0 0 300 220" role="img" aria-label="Бортик: высота, ширина и длина">${techDefs(uid)}<path d="M70 70 L170 70 L170 150 L70 150 Z" class="tech-bort-front"/><path d="M170 70 L230 40 L230 120 L170 150 Z" class="tech-bort-side"/><path d="M70 70 L130 40 L230 40 L170 70 Z" class="tech-bort-top"/><path d="M130 40 L130 52 L222 52" class="tech-bort-hidden"/><line x1="70" y1="154" x2="70" y2="183" class="tech-extension"/><line x1="170" y1="154" x2="170" y2="183" class="tech-extension"/>${techDimension(uid,70,177,170,177,120,197,"Ш")}${techDimension(uid,48,70,48,150,36,110,"В",true)}${techDimension(uid,184,162,242,132,224,164,"Д")}</svg>`;
  }

  function windowSvg(item, uid = "window") {
    const w = 100, h = 126, left = item.hinge !== "Петли справа";
    const kind = { "Глухое": "gl", "Поворотное": "tr", "Откидное": "tl", "Поворотно-откидное": "tt" }[item.kind] || "tr";
    const line = (x1,y1,x2,y2) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`;
    let opening = "";
    if (["tr","tt"].includes(kind)) opening += left ? line(w,0,0,h/2) + line(w,h,0,h/2) : line(0,0,w,h/2) + line(0,h,w,h/2);
    if (["tl","tt"].includes(kind)) opening += line(0,0,w/2,h) + line(w,0,w/2,h);
    const handle = kind === "gl" ? "" : `<rect x="${left ? w-11 : 7}" y="${h/2-8}" width="4" height="16" rx="1"/>`;
    return `<svg class="technical-svg window-svg" viewBox="0 0 260 230" role="img" aria-label="${esc(item.kind)}: высота и ширина проёма">${techDefs(uid)}<rect x="74" y="30" width="112" height="138" rx="2" class="tech-window-frame"/><g transform="translate(80 36)"><rect width="${w}" height="${h}" class="tech-window-glass"/><g class="tech-opening-lines">${opening}</g><g class="tech-window-handle">${handle}</g></g>${techDimension(uid,50,36,50,162,40,99,"Высота",true)}${techDimension(uid,80,188,180,188,130,208,"Ширина")}</svg>`;
  }

  function frameGuide() {
    return `<div class="measurement-guide"><div class="guide-figure">${schemeSvg(state.data.frame.scheme, "guide-scheme")}<span>Схема ${state.data.frame.scheme} · вид спереди</span></div><div class="guide-figure">${sectionSvg("guide-section")}<span>Сечение I–I · боковое обрамление</span></div><div class="guide-copy"><strong>Как читать размеры</strong><p><b>А</b> — высота верхнего обрамления<br><b>Н</b> — глубина обрамления<br><b>В</b> — ширина бокового обрамления</p><button class="text-button" type="button" data-action="frame-guide"><i data-lucide="expand"></i>Увеличить рисунки</button></div></div>`;
  }

  function frameAccessories(frame) {
    return `<div class="accessories-block field-wide">
      <div class="accessories-heading"><h3>Табло, загиб и кнопка вызова</h3><p>Эти параметры применяются ко всей заявке и переносятся в PDF-бланк.</p></div>
      <div class="parameter-panel">
        <div class="parameter-panel-heading"><div><strong>Табло индикации</strong><small>Отверстие в верхнем обрамлении</small></div><div class="parameter-switch"><span>${frame.displayOn ? "Есть табло" : "Нет табло"}</span>${switchControl("frame.displayOn", "Есть табло индикации")}</div></div>
        ${frame.displayOn ? `<div class="fields-grid parameter-fields"><div class="field"><span class="field-label">На каких этажах ставится <b>*</b></span><button class="display-floor-button" type="button" data-action="display-floors" aria-haspopup="dialog"><span>${esc(displayFloorLabel())}</span><i data-lucide="list-checks"></i></button><span class="field-hint">Нажмите, чтобы выбрать нужные этажи</span></div><div class="field"><span class="field-label">Отверстие под табло: высота × ширина <b>*</b></span><div class="dimension-pair">${inputValue("frame.displayH", 'aria-label="Высота отверстия под табло" placeholder="80"')}<span class="multiply">×</span>${inputValue("frame.displayW", 'aria-label="Ширина отверстия под табло" placeholder="120"')}</div></div></div>` : '<p class="parameter-empty">Табло не требуется. В бланке будет указано «Нет табло».</p>'}
      </div>
      <div class="parameter-panel">
        <div class="parameter-panel-heading"><div><strong>Загиб</strong><small>Как учитывать размеры обрамлений</small></div></div>
        <div class="fields-grid parameter-fields"><label class="field"><span class="field-label">Учёт размеров</span><span class="input-wrap"><select data-bind="frame.bendMode"><option${frame.bendMode === "С учётом загиба" ? " selected" : ""}>С учётом загиба</option><option${frame.bendMode === "Без учёта загиба" ? " selected" : ""}>Без учёта загиба</option></select></span></label><label class="field"><span class="field-label">Размер загиба <b>*</b></span>${inputValue("frame.bend", 'placeholder="20"')}</label></div>
      </div>
      <div class="parameter-panel">
        <div class="parameter-panel-heading"><div><strong>Кнопка вызова</strong><small>Расположение и отверстие в обрамлении</small></div><div class="parameter-switch"><span>Отдельно стоящая</span>${switchControl("frame.buttonSeparate", "Отдельно стоящая кнопка вызова")}</div></div>
        ${frame.buttonSeparate ? '<p class="parameter-empty">Кнопка устанавливается отдельно. Отверстие в обрамлении не требуется.</p>' : `<div class="fields-grid parameter-fields"><label class="field"><span class="field-label">На каких этажах ставится</span><span class="input-wrap"><select data-bind="frame.buttonAll"><option${frame.buttonAll === "На всех этажах" ? " selected" : ""}>На всех этажах</option><option${frame.buttonAll === "Не на всех этажах" ? " selected" : ""}>Не на всех этажах</option></select></span></label>${frame.buttonAll === "Не на всех этажах" ? `<label class="field"><span class="field-label">Номера этажей <b>*</b></span>${textInput("frame.buttonFloors", 'placeholder="1, 3, 5-7"')}</label>` : ""}<label class="field"><span class="field-label">Сторона кнопки</span><span class="input-wrap"><select data-bind="frame.buttonSide"><option${frame.buttonSide === "Слева" ? " selected" : ""}>Слева</option><option${frame.buttonSide === "Справа" ? " selected" : ""}>Справа</option></select></span></label><label class="field"><span class="field-label">От пола до центра отверстия <b>*</b></span>${inputValue("frame.buttonHeight", 'placeholder="1100"')}</label><div class="field field-wide"><span class="field-label">Отверстие под кнопку: высота × ширина <b>*</b></span><div class="dimension-pair button-hole-pair">${inputValue("frame.buttonH", 'aria-label="Высота отверстия под кнопку" placeholder="30"')}<span class="multiply">×</span>${inputValue("frame.buttonW", 'aria-label="Ширина отверстия под кнопку" placeholder="30"')}</div></div></div>`}
      </div>
    </div>`;
  }

  function extraEmpty(kind, title, description) {
    return `<div class="extra-empty"><div><strong>${title}</strong><p>${description}</p></div><button class="button button-secondary" type="button" data-extra-add="${kind}"><i data-lucide="plus"></i>Добавить</button></div>`;
  }

  function extraRemoveButton(kind, index = 0) {
    return `<button class="icon-button" type="button" data-extra-remove="${kind}" data-index="${index}" aria-label="Удалить элемент"><i data-lucide="trash-2"></i></button>`;
  }

  function renderThresholdItem(item, index) {
    const base = `frame.thresholds.${index}`;
    return `<div class="extra-item"><div class="subsection-heading"><div><span class="window-number">${index + 1}</span><h3>Порог ${index + 1}</h3></div>${extraRemoveButton("thresholds", index)}</div><div class="measurement-layout"><div class="measurement-controls"><div class="fields-grid"><label class="field"><span class="field-label">Длина порога <b>*</b></span>${inputValue(`${base}.length`, 'placeholder="1100"')}</label><label class="field"><span class="field-label">Ширина порога <b>*</b></span>${inputValue(`${base}.width`, 'placeholder="180"')}</label><label class="field"><span class="field-label">Количество отверстий Ø6</span>${unitValue(`${base}.holes`, "шт.", 'placeholder="3"')}</label><label class="field"><span class="field-label">Количество порогов <b>*</b></span>${unitValue(`${base}.qty`, "шт.", 'placeholder="9"')}</label></div></div><div class="measurement-drawing">${thresholdSvg(`threshold-${index}`)}<span>Длина × ширина, отверстия Ø6</span></div></div></div>`;
  }

  function renderNashchelnikItem(item, index) {
    const base = `frame.nashchelnik.${index}`;
    return `<div class="extra-item"><div class="subsection-heading"><div><span class="window-number">${index + 1}</span><h3>Нащельник ${index + 1}</h3></div>${extraRemoveButton("nashchelnik", index)}</div><div class="measurement-layout"><div class="measurement-controls"><div class="fields-grid"><label class="field"><span class="field-label">Длина нащельника <b>*</b></span>${inputValue(`${base}.length`, 'placeholder="2100"')}</label><label class="field"><span class="field-label">Ширина нащельника <b>*</b></span>${inputValue(`${base}.width`, 'placeholder="80"')}</label><label class="field"><span class="field-label">Количество <b>*</b></span>${unitValue(`${base}.qty`, "шт.", 'placeholder="9"')}</label></div></div><div class="measurement-drawing">${nashchelnikSvg(`nashchelnik-${index}`)}<span>Длина × ширина полки</span></div></div></div>`;
  }

  function renderBortik(key, title) {
    const item = state.data.frame.cable[key];
    if (!item) return `<div class="bortik-empty"><div><strong>${title}</strong><p>Не требуется</p></div><button class="button button-secondary" type="button" data-extra-add="${key}"><i data-lucide="plus"></i>Добавить размеры</button></div>`;
    const base = `frame.cable.${key}`;
    return `<div class="extra-item bortik-item"><div class="subsection-heading"><div><i data-lucide="box"></i><h3>${title}</h3></div>${extraRemoveButton(key)}</div><div class="measurement-layout"><div class="measurement-controls"><div class="fields-grid"><label class="field"><span class="field-label">Высота <b>*</b></span>${inputValue(`${base}.h`, 'placeholder="100"')}</label><label class="field"><span class="field-label">Ширина <b>*</b></span>${inputValue(`${base}.w`, 'placeholder="200"')}</label><label class="field"><span class="field-label">Длина <b>*</b></span>${inputValue(`${base}.l`, 'placeholder="300"')}</label><label class="field"><span class="field-label">Количество <b>*</b></span>${unitValue(`${base}.qty`, "шт.", 'placeholder="1"')}</label></div></div><div class="measurement-drawing">${bortikSvg(`bortik-${key}`)}<span>В — высота · Ш — ширина · Д — длина</span></div></div></div>`;
  }

  function showExtraDialog(kind) {
    const frame = state.data.frame;
    const dialogs = {
      thresholds: {
        title: "Пороги (рифлёнка)",
        description: "Для каждого типа укажите размеры, отверстия и общее количество.",
        content: frame.thresholds.length ? `<div class="extra-list">${frame.thresholds.map(renderThresholdItem).join("")}</div><button class="button button-secondary button-full add-window-button" type="button" data-extra-add="thresholds"><i data-lucide="plus"></i>Добавить ещё тип порога</button>` : extraEmpty("thresholds", "Добавьте первый порог", "Укажите размеры, отверстия и количество.")
      },
      nashchelnik: {
        title: "Нащельники",
        description: "Размеры и количество указываются отдельно для каждого типа нащельника.",
        content: frame.nashchelnik.length ? `<div class="extra-list">${frame.nashchelnik.map(renderNashchelnikItem).join("")}</div><button class="button button-secondary button-full add-window-button" type="button" data-extra-add="nashchelnik"><i data-lucide="plus"></i>Добавить ещё тип нащельника</button>` : extraEmpty("nashchelnik", "Добавьте первый нащельник", "Укажите размеры и количество.")
      },
      bortiki: {
        title: "Бортики",
        description: "Добавьте только нужные бортики и укажите их размеры независимо.",
        content: `<div class="bortiki-list">${renderBortik("speed_limiter", "Бортики ограничителя скорости")}${renderBortik("main_drive", "Бортики главного привода")}</div>`
      }
    };
    const dialog = dialogs[kind];
    if (!dialog) return;
    openDialog(`extra-${kind}`, "Дополнительные элементы", dialog.title, `<p class="dialog-description">${dialog.description}</p><div class="extra-dialog-content">${dialog.content}</div><div class="confirm-actions"><button class="button button-primary" type="button" data-dialog-close><i data-lucide="check"></i>Готово</button></div>`);
  }

  function renderFrameExtras() {
    const frame = state.data.frame;
    const sectionSwitch = (path, label, enabled) => `<div class="section-toggle"><span>${enabled ? "Требуются" : "Не требуются"}</span>${switchControl(path, label)}</div>`;
    const compact = (kind, text) => `<div class="extra-collapsed"><span>${text}</span><button class="button button-secondary" type="button" data-extra-open="${kind}" aria-haspopup="dialog"><i data-lucide="sliders-horizontal"></i>Изменить</button></div>`;
    const bortikCount = ["speed_limiter", "main_drive"].filter(key => frame.cable[key]).length;
    return `<section class="form-section optional-section" aria-labelledby="thresholds-title">
      <div class="section-heading"><div><span class="section-index">05</span><h2 id="thresholds-title">Пороги (рифлёнка)</h2></div>${sectionSwitch("frame.thresholdsOn", "Пороги требуются", frame.thresholdsOn)}</div>
      ${frame.thresholdsOn ? compact("thresholds", frame.thresholds.length ? `Добавлено типов: ${frame.thresholds.length}` : "Нужно добавить хотя бы один порог") : '<p class="section-description optional-description">Включите тумблер — размеры откроются в отдельном окне.</p>'}
    </section>
    <section class="form-section optional-section" aria-labelledby="nashchelnik-title">
      <div class="section-heading"><div><span class="section-index">06</span><h2 id="nashchelnik-title">Нащельники</h2></div>${sectionSwitch("frame.nashchelnikOn", "Нащельники требуются", frame.nashchelnikOn)}</div>
      ${frame.nashchelnikOn ? compact("nashchelnik", frame.nashchelnik.length ? `Добавлено типов: ${frame.nashchelnik.length}` : "Нужно добавить хотя бы один нащельник") : '<p class="section-description optional-description">Включите тумблер — размеры откроются в отдельном окне.</p>'}
    </section>
    <section class="form-section optional-section" aria-labelledby="bortiki-title">
      <div class="section-heading"><div><span class="section-index">07</span><h2 id="bortiki-title">Бортики</h2></div>${sectionSwitch("frame.bortikiOn", "Бортики требуются", frame.bortikiOn)}</div>
      ${frame.bortikiOn ? compact("bortiki", `Добавлено бортиков: ${bortikCount} из 2`) : '<p class="section-description optional-description">Включите тумблер — размеры откроются в отдельном окне.</p>'}
    </section>`;
  }

  function renderFrame() {
    ensureFloors();
    const frame = state.data.frame;
    const floors = frame.same ? [floorRow(frame.floors[0], 0, true)] : frame.floors.slice(0, Math.max(1, Number(state.data.stops) || 1)).map((floor, index) => floorRow(floor, index, false));
    return `<section class="form-section" aria-labelledby="common-params-title">
      <div class="section-heading"><div><span class="section-index">03</span><h2 id="common-params-title">Общие параметры</h2></div><span class="section-caption">Проём и портал</span></div>
      <div class="fields-grid">
        <label class="field"><span class="field-label">Ширина проёма шахты <b>*</b></span>${inputValue("frame.width", 'placeholder="900"')}</label>
        <div class="field"><span class="field-label">Портал: высота × ширина <b>*</b></span><div class="dimension-pair">${inputValue("frame.portalH", 'aria-label="Высота портала" placeholder="2100"')}<span class="multiply">×</span>${inputValue("frame.portalW", 'aria-label="Ширина портала" placeholder="1000"')}</div></div>
        <div class="scheme-picker field-wide"><span class="field-label">Схема обрамления <b>*</b></span><div class="scheme-options" role="radiogroup" aria-label="Схема обрамления">${["А", "В"].map(kind => `<button class="scheme-option ${frame.scheme === kind ? "selected" : ""}" type="button" role="radio" aria-checked="${frame.scheme === kind}" data-scheme="${kind}"><span class="scheme-drawing">${schemeSvg(kind, `picker-${kind}`)}</span><span class="scheme-copy"><strong>Схема ${kind}</strong><small>${kind === "А" ? "Верхнее обрамление накрывает боковые" : "Верхнее обрамление между боковыми"}</small></span><span class="scheme-check"><i data-lucide="check"></i></span></button>`).join("")}</div></div>
        <label class="field"><span class="field-label">Цвет</span><span class="input-wrap"><select data-bind="frame.color"><option${frame.color === "Белый, RAL 9003" ? " selected" : ""}>Белый, RAL 9003</option><option${frame.color === "Серый, RAL 7035" ? " selected" : ""}>Серый, RAL 7035</option><option${frame.color === "По каталогу RAL" ? " selected" : ""}>По каталогу RAL</option></select></span></label>
        ${frameAccessories(frame)}
        <div class="toggle-row"><div class="toggle-copy"><strong>Размеры одинаковые на всех этажах</strong><small>Один ряд размеров вместо повторного ввода</small></div>${switchControl("frame.same", "Размеры одинаковые на всех этажах")}</div>
      </div>
    </section>
    <section class="form-section" aria-labelledby="frame-sizes-title">
      <div class="section-heading"><div><span class="section-index">04</span><h2 id="frame-sizes-title">Размеры обрамлений</h2></div><span class="section-caption">Все значения в мм</span></div>
      ${frameGuide()}
      <div class="floor-toolbar"><p>${frame.same ? "Заполните один раз — значения применятся ко всем этажам." : "Введите размеры отдельно для каждого этажа."}</p>${!frame.same ? '<button class="icon-text-button" type="button" data-action="copy-floor"><i data-lucide="copy-plus"></i>Как 1-й этаж</button>' : ""}</div>
      <div class="floor-list">${floors.join("")}</div>
    </section>${renderFrameExtras()}`;
  }

  function renderDoor() {
    const door = state.data.door;
    return `<section class="form-section" aria-labelledby="door-params-title">
      <div class="section-heading"><div><span class="section-index">03</span><h2 id="door-params-title">Двери и люки</h2></div><span class="section-caption">Строительные проёмы</span></div>
      <div class="subsection ${door.needDoor ? "" : "subsection-disabled"}">
        <div class="subsection-heading"><div><i data-lucide="door-open"></i><h3>Дверь шахты</h3></div>${switchControl("door.needDoor", "Дверь требуется")}</div>
        <div class="subsection-content"><div class="measurement-layout"><div class="measurement-controls"><div class="fields-grid">
          <label class="field"><span class="field-label">Высота проёма <b>*</b></span>${inputValue("door.doorH", 'placeholder="2000"')}</label>
          <label class="field"><span class="field-label">Ширина проёма <b>*</b></span>${inputValue("door.doorW", 'placeholder="800"')}</label>
          <label class="field"><span class="field-label">Количество <b>*</b></span>${textInput("door.doorQty", 'inputmode="numeric" placeholder="1"')}</label>
          <label class="field"><span class="field-label">Открывание</span><span class="input-wrap"><select data-bind="door.hinge"><option${door.hinge === "Петли справа" ? " selected" : ""}>Петли справа</option><option${door.hinge === "Петли слева" ? " selected" : ""}>Петли слева</option></select></span></label>
        </div><p class="calculation" id="door-calculation">${door.doorH && door.doorW ? `Размер двери: ${Math.max(0, Number(door.doorH) - 20)} × ${Math.max(0, Number(door.doorW) - 40)} мм` : "Размер двери рассчитается автоматически"}</p>
        <div class="casing-row"><span class="field-label" style="width:100%;margin:0">Наличник</span><label class="check-chip"><input type="checkbox" data-bind="door.casingLeft" ${door.casingLeft ? "checked" : ""}><span>Слева</span></label><label class="check-chip"><input type="checkbox" data-bind="door.casingTop" ${door.casingTop ? "checked" : ""}><span>Сверху</span></label><label class="check-chip"><input type="checkbox" data-bind="door.casingRight" ${door.casingRight ? "checked" : ""}><span>Справа</span></label></div></div><div class="measurement-drawing">${doorSvg({ left: door.casingLeft, top: door.casingTop, right: door.casingRight }, door.hinge, "door-guide-small")}<span>Высота и ширина — строительный проём</span><button class="text-button" type="button" data-action="door-guide"><i data-lucide="expand"></i>Увеличить</button></div></div></div>
      </div>
      <div class="subsection ${door.needHatch ? "" : "subsection-disabled"}">
        <div class="subsection-heading"><div><i data-lucide="square-dashed"></i><h3>Люк</h3></div>${switchControl("door.needHatch", "Люк требуется")}</div>
        <div class="subsection-content"><div class="measurement-layout"><div class="measurement-controls"><div class="fields-grid">
          <label class="field"><span class="field-label">Высота проёма <b>*</b></span>${inputValue("door.hatchH", 'placeholder="600"')}</label>
          <label class="field"><span class="field-label">Ширина проёма <b>*</b></span>${inputValue("door.hatchW", 'placeholder="600"')}</label>
          <label class="field"><span class="field-label">Количество <b>*</b></span>${textInput("door.hatchQty", 'inputmode="numeric" placeholder="1"')}</label>
        </div><p class="calculation">${door.hatchH && door.hatchW ? `Размер люка: ${Math.max(0, Number(door.hatchH) - 10)} × ${Math.max(0, Number(door.hatchW) - 10)} мм · наличник со всех сторон` : "Размер люка рассчитается автоматически"}</p></div><div class="measurement-drawing">${hatchSvg("hatch-guide-small")}<span>Петли расположены напротив ручки</span><button class="text-button" type="button" data-action="hatch-guide"><i data-lucide="expand"></i>Увеличить</button></div></div></div>
      </div>
      <div class="info-strip"><i data-lucide="info"></i><span>Габариты изделия рассчитываются из строительного проёма автоматически — отдельно вычислять их не нужно.</span></div>
    </section>`;
  }

  function renderWindowItem(item, index) {
    const base = `window.items.${index}`;
    return `<div class="window-item"><div class="subsection-heading"><div><span class="window-number">${index + 1}</span><h3>Окно ${index + 1}</h3></div><div class="window-actions"><button class="icon-button" type="button" data-window-copy="${index}" aria-label="Продублировать окно ${index + 1}" title="Продублировать"><i data-lucide="copy"></i></button>${state.data.window.items.length > 1 ? `<button class="icon-button" type="button" data-window-remove="${index}" aria-label="Удалить окно ${index + 1}" title="Удалить"><i data-lucide="trash-2"></i></button>` : ""}</div></div>
      <div class="window-measurement"><div class="window-controls"><div class="fields-grid">
        <label class="field field-wide"><span class="field-label">Тип открывания <b>*</b></span><span class="input-wrap"><select data-bind="${base}.kind">${["Глухое", "Поворотное", "Поворотно-откидное"].map(kind => `<option${item.kind === kind ? " selected" : ""}>${kind}</option>`).join("")}</select></span></label>
        <label class="field"><span class="field-label">Высота проёма <b>*</b></span>${inputValue(`${base}.h`, 'placeholder="1200"')}</label>
        <label class="field"><span class="field-label">Ширина проёма <b>*</b></span>${inputValue(`${base}.w`, 'placeholder="800"')}</label>
        <label class="field"><span class="field-label">Количество <b>*</b></span>${textInput(`${base}.qty`, 'inputmode="numeric" placeholder="1"')}</label>
        <label class="field"><span class="field-label">Петли</span><span class="input-wrap"><select data-bind="${base}.hinge"><option${item.hinge === "Петли справа" ? " selected" : ""}>Петли справа</option><option${item.hinge === "Петли слева" ? " selected" : ""}>Петли слева</option><option${item.hinge === "Не требуется" ? " selected" : ""}>Не требуется</option></select></span></label>
      </div><p class="calculation">${item.h && item.w ? `Размер окна: ${Math.max(0, Number(item.h) - 20)} × ${Math.max(0, Number(item.w) - 40)} мм` : "Размер окна рассчитается автоматически"}</p></div><div class="measurement-drawing window-drawing">${windowSvg(item, `window-guide-${index}`)}<span>Схема открывания и проём</span><button class="text-button" type="button" data-action="window-guide" data-index="${index}"><i data-lucide="expand"></i>Увеличить</button></div></div>
      <div class="toggle-row"><div class="toggle-copy"><strong>Отлив</strong><small>Добавить размеры отлива к этому окну</small></div>${switchControl(`${base}.ebb`, `Отлив для окна ${index + 1}`)}</div>
      ${item.ebb ? `<div class="fields-grid" style="margin-top:13px"><label class="field"><span class="field-label">Длина отлива <b>*</b></span>${inputValue(`${base}.ebbL`, 'placeholder="1250"')}</label><label class="field"><span class="field-label">Ширина отлива <b>*</b></span>${inputValue(`${base}.ebbW`, 'placeholder="150"')}</label></div>` : ""}
    </div>`;
  }

  function renderWindow() {
    const items = state.data.window.items;
    return `<section class="form-section" aria-labelledby="window-params-title"><div class="section-heading"><div><span class="section-index">03</span><h2 id="window-params-title">Размеры окон</h2></div><span class="section-caption">${items.length} ${items.length === 1 ? "позиция" : "позиции"}</span></div>
      <div class="window-list">${items.map(renderWindowItem).join("")}</div>
      <button class="button button-secondary button-full add-window-button" type="button" data-action="add-window"><i data-lucide="plus"></i>Добавить ещё окно</button>
      <div class="info-strip"><i data-lucide="info"></i><span>Повторяющееся окно можно продублировать вместе с размерами, открыванием и отливом.</span></div>
    </section>`;
  }

  function renderTypeFields() {
    $("#type-fields").innerHTML = state.data.type === "frame" ? renderFrame() : state.data.type === "door" ? renderDoor() : renderWindow();
    $$("[data-type]").forEach(button => button.setAttribute("aria-selected", String(button.dataset.type === state.data.type)));
    $("#stops-label").innerHTML = 'Этажей / остановок <b>*</b>';
    $("#notes-title").parentElement.querySelector(".section-index").textContent = state.data.type === "frame" ? "08" : "05";
    icons();
  }

  function requiredPaths() {
    const paths = ["address", "stops"];
    if (state.data.type === "frame") {
      paths.push("frame.width", "frame.portalH", "frame.portalW", "frame.bend");
      if (state.data.frame.displayOn) paths.push("frame.displayFloors", "frame.displayH", "frame.displayW");
      if (!state.data.frame.buttonSeparate) {
        paths.push("frame.buttonHeight", "frame.buttonH", "frame.buttonW");
        if (state.data.frame.buttonAll === "Не на всех этажах") paths.push("frame.buttonFloors");
      }
      const count = state.data.frame.same ? 1 : Math.max(1, Number(state.data.stops) || 1);
      for (let index = 0; index < count; index++) {
        ["topA", "topH", "leftH", "leftB", "rightH", "rightB"].forEach(key => paths.push(`frame.floors.${index}.${key}`));
      }
      if (state.data.frame.thresholdsOn) {
        if (!state.data.frame.thresholds.length) paths.push("frame.thresholds");
        state.data.frame.thresholds.forEach((item, index) => ["length", "width", "holes", "qty"].forEach(key => paths.push(`frame.thresholds.${index}.${key}`)));
      }
      if (state.data.frame.nashchelnikOn) {
        if (!state.data.frame.nashchelnik.length) paths.push("frame.nashchelnik");
        state.data.frame.nashchelnik.forEach((item, index) => ["length", "width", "qty"].forEach(key => paths.push(`frame.nashchelnik.${index}.${key}`)));
      }
      if (state.data.frame.bortikiOn) {
        if (!state.data.frame.cable.speed_limiter && !state.data.frame.cable.main_drive) paths.push("frame.cable.speed_limiter");
        ["speed_limiter", "main_drive"].forEach(key => {
          if (state.data.frame.cable[key]) ["h", "w", "l", "qty"].forEach(field => paths.push(`frame.cable.${key}.${field}`));
        });
      }
    } else if (state.data.type === "door") {
      if (state.data.door.needDoor) paths.push("door.doorH", "door.doorW", "door.doorQty");
      if (state.data.door.needHatch) paths.push("door.hatchH", "door.hatchW", "door.hatchQty");
    } else {
      state.data.window.items.forEach((item, index) => {
        paths.push(`window.items.${index}.kind`, `window.items.${index}.h`, `window.items.${index}.w`, `window.items.${index}.qty`);
        if (item.ebb) paths.push(`window.items.${index}.ebbL`, `window.items.${index}.ebbW`);
      });
    }
    return paths;
  }

  function filled(path) {
    const value = getPath(state.data, path);
    if (path === "frame.displayFloors") return displayFloorSelection().length > 0;
    if (path.endsWith(".holes")) return String(value ?? "").trim() !== "" && Number(value) >= 0;
    if (["stops", "frame.width", "frame.portalH", "frame.portalW"].includes(path) || /(topA|topH|leftH|leftB|rightH|rightB|displayH|displayW|buttonHeight|buttonH|buttonW|doorH|doorW|doorQty|hatchH|hatchW|hatchQty|length|width|\.h$|\.w$|\.l$|\.qty$|ebbL|ebbW)$/.test(path)) return Number(value) > 0;
    return String(value ?? "").trim().length > 0;
  }

  function completion() {
    const paths = requiredPaths();
    const done = paths.filter(filled).length;
    return { paths, done, total: paths.length, percent: paths.length ? Math.round(done / paths.length * 100) : 0 };
  }

  function summaryRows() {
    const data = state.data;
    const rows = [
      ["Объект", data.address || "Не указан", !data.address],
      ["Вид замера", TYPE_META[data.type].name, false]
    ];
    if (data.type === "frame") {
      rows.push(["Схема", `Схема ${data.frame.scheme}`, false]);
      rows.push(["Этажи", `${data.stops || "—"} · ${data.frame.same ? "одинаковые" : "по отдельности"}`, !data.stops]);
      rows.push(["Проём шахты", data.frame.width ? `${data.frame.width} мм` : "Не заполнен", !filled("frame.width")]);
      rows.push(["Портал", data.frame.portalH && data.frame.portalW ? `${data.frame.portalH} × ${data.frame.portalW} мм` : "Не заполнен", !filled("frame.portalH") || !filled("frame.portalW")]);
      rows.push(["Табло", data.frame.displayOn ? `${displayFloorLabel(data)}${data.frame.displayH && data.frame.displayW ? ` · ${data.frame.displayH} × ${data.frame.displayW} мм` : ""}` : "Нет табло", data.frame.displayOn && (!filled("frame.displayFloors") || !filled("frame.displayH") || !filled("frame.displayW"))]);
      rows.push(["Загиб", `${data.frame.bendMode}${data.frame.bend !== "" ? ` · ${data.frame.bend} мм` : ""}`, data.frame.bend === ""]);
      rows.push(["Кнопка", data.frame.buttonSeparate ? "Отдельно стоящая" : `${data.frame.buttonAll === "Не на всех этажах" ? `Этажи: ${data.frame.buttonFloors || "—"}` : data.frame.buttonAll} · ${data.frame.buttonSide.toLowerCase()}${data.frame.buttonHeight ? ` · ${data.frame.buttonHeight} мм` : ""}${data.frame.buttonH && data.frame.buttonW ? ` · отв. ${data.frame.buttonH} × ${data.frame.buttonW}` : ""}`, !data.frame.buttonSeparate && (!filled("frame.buttonHeight") || !filled("frame.buttonH") || !filled("frame.buttonW"))]);
      const thresholds = data.frame.thresholdsOn ? data.frame.thresholds || [] : [];
      const trims = data.frame.nashchelnikOn ? data.frame.nashchelnik || [] : [];
      const thresholdText = !data.frame.thresholdsOn ? "Не требуется" : thresholds.length ? thresholds.map(item => `${item.length || "—"} × ${item.width || "—"} мм · ${item.qty || "—"} шт.`).join("; ") : "Добавьте позицию";
      const trimText = !data.frame.nashchelnikOn ? "Не требуется" : trims.length ? trims.map(item => `${item.length || "—"} × ${item.width || "—"} мм · ${item.qty || "—"} шт.`).join("; ") : "Добавьте позицию";
      const thresholdMissing = data.frame.thresholdsOn && (!thresholds.length || thresholds.some((item, index) => ["length", "width", "holes", "qty"].some(key => !filled(`frame.thresholds.${index}.${key}`))));
      const trimMissing = data.frame.nashchelnikOn && (!trims.length || trims.some((item, index) => ["length", "width", "qty"].some(key => !filled(`frame.nashchelnik.${index}.${key}`))));
      const guards = data.frame.bortikiOn ? [["speed_limiter", "Ограничитель скорости"], ["main_drive", "Главный привод"]].filter(([key]) => data.frame.cable?.[key]) : [];
      const guardMissing = data.frame.bortikiOn && (!guards.length || guards.some(([key]) => ["h", "w", "l", "qty"].some(field => !filled(`frame.cable.${key}.${field}`))));
      rows.push(["Пороги", thresholdText, thresholdMissing]);
      rows.push(["Нащельники", trimText, trimMissing]);
      rows.push(["Бортики", !data.frame.bortikiOn ? "Не требуется" : guards.length ? guards.map(([key, label]) => { const item = data.frame.cable[key]; return `${label}: ${item.h || "—"} × ${item.w || "—"} × ${item.l || "—"} мм · ${item.qty || "—"} шт.`; }).join("; ") : "Добавьте позицию", guardMissing]);
    } else if (data.type === "door") {
      rows.push(["Дверь", data.door.needDoor ? (data.door.doorH && data.door.doorW ? `${data.door.doorH} × ${data.door.doorW} мм · ${data.door.doorQty || 0} шт.` : "Нужны размеры") : "Не требуется", data.door.needDoor && (!filled("door.doorH") || !filled("door.doorW"))]);
      rows.push(["Люк", data.door.needHatch ? (data.door.hatchH && data.door.hatchW ? `${data.door.hatchH} × ${data.door.hatchW} мм · ${data.door.hatchQty || 0} шт.` : "Нужны размеры") : "Не требуется", data.door.needHatch && (!filled("door.hatchH") || !filled("door.hatchW"))]);
      rows.push(["Подъездов", `${data.entrances || 0}`, false]);
    } else {
      const totalQty = data.window.items.reduce((sum, item) => sum + (Number(item.qty) || 0), 0);
      const first = data.window.items[0];
      rows.push(["Позиций", `${data.window.items.length} · всего ${totalQty} шт.`, false]);
      rows.push(["Первый проём", first?.h && first?.w ? `${first.h} × ${first.w} мм` : "Не заполнен", !first?.h || !first?.w]);
      rows.push(["Отливы", `${data.window.items.filter(item => item.ebb).length} из ${data.window.items.length}`, false]);
    }
    return rows;
  }

  function updateSummary() {
    const result = completion();
    const ready = result.done === result.total && (state.data.type !== "door" || state.data.door.needDoor || state.data.door.needHatch);
    const remaining = result.total - result.done;
    const queueOnline = !state.demoOffline && state.queue.length > 0;
    $("#summary-card").innerHTML = `<div class="summary-head"><div class="summary-title-row"><h2>Готовность заявки</h2><span class="summary-percent">${result.percent}%</span></div><div class="progress-track" role="progressbar" aria-valuenow="${result.percent}" aria-valuemin="0" aria-valuemax="100" aria-label="Заполнение обязательных полей"><div class="progress-value" style="width:${result.percent}%"></div></div><p>${ready ? "Все обязательные поля заполнены" : `Осталось заполнить: ${remaining} ${remaining === 1 ? "поле" : remaining < 5 ? "поля" : "полей"}`}</p></div>
      <dl class="summary-content">${summaryRows().map(([label, value, empty]) => `<div class="summary-row"><dt>${label}</dt><dd class="${empty ? "empty" : ""}">${esc(value)}</dd></div>`).join("")}</dl>
      <div class="summary-footer"><button class="button button-primary button-full" type="button" data-action="submit">${ready ? "Отправить замер" : "Проверить и отправить"}<i data-lucide="arrow-right"></i></button><button class="button button-secondary button-full pdf-button" type="button" data-action="pdf" ${state.pdfBusy ? "disabled aria-busy=\"true\"" : "aria-busy=\"false\""}><i data-lucide="file-down"></i><span data-pdf-label>${state.pdfBusy ? "Формируем PDF…" : "Скачать PDF-бланк"}</span></button><button class="button button-secondary button-full" type="button" data-action="${queueOnline ? "sync" : "save"}"><i data-lucide="${queueOnline ? "refresh-cw" : "save"}"></i>${queueOnline ? `Синхронизировать (${state.queue.length})` : "Сохранить черновик"}</button><p class="summary-status ${ready ? "ready" : ""}"><i data-lucide="${state.demoOffline ? "cloud-off" : ready ? "circle-check" : "cloud"}"></i>${state.demoOffline ? "Отправка будет поставлена в очередь" : state.queue.length ? `Ожидают синхронизации: ${state.queue.length}` : ready ? "Можно отправлять в общую базу" : "Черновик сохраняется автоматически"}</p></div>`;
    icons();
  }

  function syncStaticInputs() {
    ["address", "contact", "entrances", "stops", "comment"].forEach(key => {
      const input = document.getElementById(key);
      if (input) input.value = state.data[key] ?? "";
    });
  }

  function visibleRequests() {
    const own = state.role === "surveyor" ? "Алексей Петров" : null;
    const queued = state.queue.map(item => ({ ...item, status: "Ожидает синхронизации" }));
    return [...queued, ...state.requests].filter(request => !own || request.owner === own);
  }

  function updateHeader() {
    const manager = state.role === "manager";
    $("#profile-name").textContent = manager ? "Ирина Соколова" : "Алексей Петров";
    $("#profile-role").textContent = manager ? "Руководитель" : "Замерщик";
    $("#avatar").textContent = manager ? "ИС" : "АП";
    $("#requests-nav-label").textContent = manager ? "Заявки команды" : "Мои заявки";
    $("#access-description").textContent = manager ? "Вам доступны заявки всех замерщиков, их статусы и история синхронизации." : "Вы видите свои заявки. Руководителю доступны замеры всей команды.";
    const count = visibleRequests().length;
    $("#requests-count").textContent = count;
    $(".shortcut-count").textContent = count;
    $("#draft-number").textContent = `Черновик ${state.draftId}`;
  }

  function updateConnectivity() {
    const offline = state.demoOffline || !navigator.onLine;
    const button = $("#connection-button");
    button.classList.toggle("offline", offline);
    $("#connection-label").textContent = offline ? "Офлайн" : "Онлайн";
    $(".connection-icon").outerHTML = `<i data-lucide="${offline ? "cloud-off" : "wifi"}" class="connection-icon"></i>`;
    $("#offline-banner").hidden = !offline;
    $("#queue-label").hidden = !state.queue.length;
    $("#queue-label").textContent = state.queue.length ? `В очереди: ${state.queue.length}` : "";
    const save = $("#save-state");
    save.classList.toggle("offline", offline);
    if (offline) save.innerHTML = '<i data-lucide="hard-drive"></i>На устройстве';
    else save.innerHTML = '<i data-lucide="check"></i>Сохранён';
    updateSummary();
    icons();
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ data: state.data, role: state.role, queue: state.queue, requests: state.requests, draftId: state.draftId }));
      return true;
    } catch (_) { return false; }
  }

  function scheduleSave() {
    clearTimeout(state.saveTimer);
    const save = $("#save-state");
    save.className = "save-state saving";
    save.innerHTML = '<i data-lucide="loader-circle"></i>Сохранение…';
    icons();
    state.saveTimer = setTimeout(() => {
      persist();
      updateConnectivity();
    }, 450);
  }

  function touch({ summary = true } = {}) {
    if (summary) updateSummary();
    scheduleSave();
  }

  function showToast(message, icon = "check") {
    clearTimeout(state.toastTimer);
    $("#toast-text").textContent = message;
    $(".toast-icon").innerHTML = `<i data-lucide="${icon}"></i>`;
    $("#toast").classList.add("visible");
    icons();
    state.toastTimer = setTimeout(() => $("#toast").classList.remove("visible"), 4200);
  }

  function openDialog(view, eyebrow, title, html) {
    state.dialogView = view;
    const dialog = $("#app-dialog");
    if (!dialog.open) state.lastFocus = document.activeElement;
    $("#dialog-eyebrow").textContent = eyebrow;
    $("#dialog-title").textContent = title;
    $("#dialog-body").innerHTML = html;
    dialog.classList.toggle("extra-dialog", view.startsWith("extra-"));
    if (!dialog.open) dialog.showModal();
    icons();
    requestAnimationFrame(() => $(".dialog-header [data-dialog-close]")?.focus());
  }

  function closeDialog() {
    $("#app-dialog").close();
    state.dialogView = null;
    state.displayFloorDraft = null;
    state.lastFocus?.focus?.();
  }

  function showDrawingGuide(kind, index = 0) {
    if (kind === "frame") {
      openDialog("drawing", "Подсказка по размерам", `Схема ${state.data.frame.scheme} и сечение обрамления`, `<p class="dialog-description">Сверяйте буквы на рисунке с названиями полей. Все размеры указываются в миллиметрах.</p><div class="drawing-dialog-grid"><div class="drawing-dialog-figure">${schemeSvg(state.data.frame.scheme, "dialog-scheme")}<strong>Схема ${state.data.frame.scheme}</strong><span>${state.data.frame.scheme === "А" ? "Верхнее обрамление накрывает боковые" : "Верхнее обрамление между боковыми"}</span></div><div class="drawing-dialog-figure">${sectionSvg("dialog-section")}<strong>Сечение I–I</strong><span>Н — глубина, В — ширина бокового обрамления</span></div></div><div class="info-strip"><i data-lucide="info"></i><span><b>А</b> — высота верхнего обрамления. Для схемы А измеряется по месту перекрытия боковых элементов.</span></div>`);
    } else if (kind === "door") {
      const door = state.data.door;
      openDialog("drawing", "Подсказка по размерам", "Дверь шахты", `<div class="single-drawing">${doorSvg({ left: door.casingLeft, top: door.casingTop, right: door.casingRight }, door.hinge, "dialog-door")}</div><p class="dialog-description">Высота и ширина — размеры строительного проёма. Галочки показывают стороны, где нужен наличник. Изменить их можно под полями замера.</p>`);
    } else if (kind === "hatch") {
      openDialog("drawing", "Подсказка по размерам", "Люк", `<div class="single-drawing">${hatchSvg("dialog-hatch")}</div><p class="dialog-description">Укажите строительный проём. Размер люка рассчитывается автоматически: высота и ширина минус 10 мм. Наличник предусмотрен со всех сторон, петли — напротив ручки.</p>`);
    } else {
      const item = state.data.window.items[index];
      if (!item) return;
      openDialog("drawing", `Окно ${index + 1}`, item.kind, `<div class="single-drawing">${windowSvg(item, "dialog-window")}</div><p class="dialog-description">Линии внутри створки показывают направление открывания. Высота и ширина — размеры строительного проёма; размер окна рассчитывается автоматически.</p>`);
    }
  }

  function showTemplates() {
    openDialog("templates", "Быстрый старт", "Шаблоны типовых объектов", `<p class="dialog-description">Шаблон подставит вид замера, количество этажей и типовые размеры. Адрес и любые значения можно изменить.</p><div class="option-list">${templates.map(template => `<button class="option-card" type="button" data-template="${template.id}"><span class="option-card-icon"><i data-lucide="${TYPE_META[template.type].icon}"></i></span><span class="option-card-copy"><strong>${template.title}</strong><small>${template.description}</small></span><span class="option-card-meta"><b>${template.meta}</b>заполнены</span><i data-lucide="chevron-right"></i></button>`).join("")}</div>`);
  }

  function requestDescription(request) {
    const data = request.data;
    let detail = TYPE_META[data.type].name;
    if (data.type === "frame") detail += ` · ${data.stops} эт.`;
    if (data.type === "door") detail += ` · ${data.door.doorQty || 1} дверь`;
    if (data.type === "window") detail += ` · ${data.window.items.length} поз.`;
    return detail;
  }

  function showCopy() {
    const list = state.requests.filter(request => request.owner === "Алексей Петров").slice(0, 4);
    openDialog("copy", "Повторное использование", "Скопировать прошлую заявку", `<p class="dialog-description">Создастся новый черновик. Скопируются адрес, параметры и все размеры, а старый замер не изменится.</p><div class="option-list">${list.map(request => `<button class="option-card" type="button" data-copy-request="${request.id}"><span class="option-card-icon"><i data-lucide="copy"></i></span><span class="option-card-copy"><strong>${esc(request.data.address)}</strong><small>${requestDescription(request)} · ${request.date}</small></span><i data-lucide="chevron-right"></i></button>`).join("")}</div>`);
  }

  function showRequests() {
    const list = visibleRequests();
    const canSync = !state.demoOffline && state.queue.length > 0;
    openDialog("requests", state.role === "manager" ? "Общая база" : "Личный список", state.role === "manager" ? "Заявки команды" : "Мои заявки", `${canSync ? `<button class="button button-primary button-full" type="button" data-action="sync"><i data-lucide="refresh-cw"></i>Синхронизировать очередь (${state.queue.length})</button><div class="dialog-section-label">Последние заявки</div>` : `<p class="dialog-description">${state.role === "manager" ? "Показаны заявки всех сотрудников. Нажмите на строку, чтобы посмотреть детали." : "Здесь только ваши заявки. Нажмите на строку, чтобы посмотреть детали или повторить замер."}</p>`}<div class="option-list">${list.length ? list.map(request => `<button class="option-card" type="button" data-request="${request.id}"><span class="option-card-icon"><i data-lucide="${request.status === "Ожидает синхронизации" ? "cloud-off" : TYPE_META[request.data.type].icon}"></i></span><span class="option-card-copy"><strong>${esc(request.data.address)}</strong><small>${request.id} · ${requestDescription(request)}${state.role === "manager" ? ` · ${request.owner}` : ""}</small></span><span class="option-card-meta"><b>${request.status === "Ожидает синхронизации" ? "В очереди" : "В базе"}</b>${request.date}</span><i data-lucide="chevron-right"></i></button>`).join("") : '<div class="empty-state"><i data-lucide="clipboard-list"></i><h3>Заявок пока нет</h3><p>Новый отправленный замер появится здесь.</p></div>'}</div>`);
  }

  function showRequest(id) {
    const request = visibleRequests().find(item => item.id === id);
    if (!request) return;
    const rows = summaryRowsFor(request.data);
    openDialog("request", request.id, request.data.address, `<p class="dialog-description">${requestDescription(request)} · ${request.owner}<br>${request.date} · ${request.status}</p><dl class="summary-content" style="padding:0">${rows.map(([label, value, empty]) => `<div class="summary-row"><dt>${label}</dt><dd class="${empty ? "empty" : ""}">${esc(value)}</dd></div>`).join("")}</dl><div class="confirm-actions"><button class="button button-secondary" type="button" data-action="requests">Назад</button><button class="button button-primary" type="button" data-copy-request="${request.id}"><i data-lucide="copy"></i>Повторить замер</button></div>`);
  }

  function summaryRowsFor(data) {
    const current = state.data;
    state.data = normalizeData(data);
    const rows = summaryRows();
    state.data = current;
    return rows;
  }

  function freshDraftId() {
    const numbers = [...state.requests, ...state.queue, { id: state.draftId }].map(item => Number(String(item.id).replace(/\D/g, "")) || 0);
    return `ДШ-${Math.max(1048, ...numbers) + 1}`;
  }

  function renderAll() {
    syncStaticInputs();
    renderTypeFields();
    updateHeader();
    updateConnectivity();
    clearErrors();
    icons();
  }

  function applyData(data, message) {
    state.data = normalizeData(clone(data));
    state.draftId = freshDraftId();
    ensureFloors();
    renderAll();
    persist();
    closeDialog();
    window.scrollTo({ top: 0, behavior: "smooth" });
    showToast(message, "sparkles");
  }

  function showResetConfirm() {
    openDialog("reset", "Новый замер", "Очистить текущий черновик?", `<p class="dialog-description">Все введённые на этом экране значения будут удалены с этого устройства. Ранее отправленные заявки останутся без изменений.</p><div class="confirm-actions"><button class="button button-secondary" type="button" data-dialog-close>Отмена</button><button class="button button-primary" type="button" data-action="confirm-reset"><i data-lucide="rotate-ccw"></i>Очистить и начать заново</button></div>`);
  }

  function clearErrors() {
    $$(".field-error").forEach(element => element.classList.remove("field-error"));
    $$(".input-error").forEach(element => element.classList.remove("input-error"));
  }

  function validateBeforeSubmit() {
    clearErrors();
    const missing = requiredPaths().filter(path => !filled(path));
    if (state.data.type === "door" && !state.data.door.needDoor && !state.data.door.needHatch) {
      showToast("Включите дверь или люк — иначе в замере нет позиций", "info");
      $(".subsection .switch")?.focus();
      return false;
    }
    if (state.data.type === "frame" && state.data.frame.displayOn && !filled("frame.displayFloors")) {
      const button = $("[data-action=\"display-floors\"]");
      button?.classList.add("input-error");
      button?.closest(".field")?.classList.add("field-error");
      button?.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => button?.focus({ preventScroll: true }), 350);
      showToast("Выберите хотя бы один этаж для табло или выключите табло", "info");
      return false;
    }
    if (!missing.length) return true;
    const extraKind = missing[0].startsWith("frame.thresholds") ? "thresholds" : missing[0].startsWith("frame.nashchelnik") ? "nashchelnik" : missing[0].startsWith("frame.cable") ? "bortiki" : null;
    if (extraKind) {
      showExtraDialog(extraKind);
      missing.forEach(path => {
        const input = $(`[data-bind="${path}"]`);
        input?.classList.add("input-error");
        input?.closest(".field")?.classList.add("field-error");
      });
      const first = $(`[data-bind="${missing[0]}"]`);
      first?.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => first?.focus({ preventScroll: true }), 80);
      showToast("Заполните размеры и количество во всплывающем окне", "info");
      return false;
    }
    missing.forEach(path => {
      const input = $(`[data-bind="${path}"]`) || document.getElementById(path);
      if (!input) return;
      input.classList.add("input-error");
      input.closest(".field")?.classList.add("field-error");
    });
    const first = $(`[data-bind="${missing[0]}"]`) || document.getElementById(missing[0]);
    first?.scrollIntoView({ behavior: "smooth", block: "center" });
    setTimeout(() => first?.focus({ preventScroll: true }), 350);
    showToast(`Заполните обязательные поля: ${missing.length}`, "info");
    return false;
  }

  function exportPdfOrder() {
    const data = state.data;
    const base = {
      stamp: new Date().toLocaleString("ru-RU", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" }),
      address: String(data.address || "").trim(),
      contact: String(data.contact || "").trim(),
      comment: String(data.comment || "").trim(),
      worker: state.role === "manager" ? "Ирина Соколова" : "Алексей Петров"
    };

    if (data.type === "door") {
      const door = data.door;
      const mult = Math.max(1, Number(data.entrances) || 1);
      return {
        ...base,
        kind: "dl",
        items: [{
          label: mult > 1 ? `Все подъезды (${mult})` : "Подъезд 1",
          mult,
          door: door.needDoor ? {
            need: "Да", h: door.doorH, w: door.doorW, qty: door.doorQty,
            hinge: door.hinge === "Петли справа" ? "Справа" : "Слева",
            cas: { l: door.casingLeft, t: door.casingTop, r: door.casingRight }
          } : { need: "Нет" },
          hatch: door.needHatch ? {
            need: "Да", h: door.hatchH, w: door.hatchW, qty: door.hatchQty,
            hinge: "Слева", cas: { l: true, t: true, r: true, b: true }
          } : { need: "Нет" }
        }]
      };
    }

    if (data.type === "window") {
      const kinds = { "Глухое": "gl", "Поворотное": "tr", "Откидное": "tl", "Поворотно-откидное": "tt" };
      return {
        ...base,
        kind: "win",
        items: data.window.items.map((item, index) => ({
          n: index + 1,
          kind: kinds[item.kind] || "tr",
          h: item.h,
          w: item.w,
          qty: item.qty,
          hinge: item.hinge === "Петли справа" ? "Справа" : item.hinge === "Петли слева" ? "Слева" : "",
          ebb: item.ebb ? { l: item.ebbL, w: item.ebbW } : null
        }))
      };
    }

    const frame = data.frame;
    const stops = Math.max(1, Number(data.stops) || 1);
    const cable = {};
    if (frame.bortikiOn) {
      ["speed_limiter", "main_drive"].forEach(key => {
        if (frame.cable?.[key]) cable[key] = clone(frame.cable[key]);
      });
    }
    return {
      ...base,
      kind: "frame",
      scheme: frame.scheme,
      stops,
      dsh_same: frame.same,
      common: {
        color: frame.color,
        bend_mode: frame.bendMode,
        bend: frame.bend,
        ind_floor: frame.displayOn ? displayFloorLabel(data) : "Нет табло",
        ind_size: frame.displayOn && frame.displayH && frame.displayW ? `${frame.displayH} × ${frame.displayW}` : "",
        btn_sep: frame.buttonSeparate ? "Да" : "Нет",
        btn_all: frame.buttonAll,
        btn_floors: frame.buttonFloors,
        btn_side: frame.buttonSeparate ? "" : frame.buttonSide,
        btn_height: frame.buttonSeparate ? "" : frame.buttonHeight,
        btn_size: !frame.buttonSeparate && frame.buttonH && frame.buttonW ? `${frame.buttonH} × ${frame.buttonW}` : "",
        portal_size: frame.portalH && frame.portalW ? `${frame.portalH} × ${frame.portalW} мм` : ""
      },
      thresholds: frame.thresholdsOn ? clone(frame.thresholds || []) : [],
      nashchelnik: frame.nashchelnikOn ? clone(frame.nashchelnik || []) : [],
      cable,
      openings: Array.from({ length: stops }, (_, index) => {
        const floor = frame.floors[frame.same ? 0 : index] || frame.floors[0] || emptyFloor();
        return {
          floor: index + 1,
          width: frame.width,
          C: frame.portalH,
          qty: 1,
          top_A: floor.topA,
          top_H: floor.topH,
          left_H: floor.leftH,
          left_B: floor.leftB,
          right_H: floor.rightH,
          right_B: floor.rightB
        };
      })
    };
  }

  function updatePdfButtons() {
    $$('[data-action="pdf"]').forEach(button => {
      button.disabled = state.pdfBusy;
      button.setAttribute("aria-busy", String(state.pdfBusy));
      const label = $("[data-pdf-label]", button);
      if (label) label.textContent = state.pdfBusy
        ? (button.classList.contains("mobile-pdf-button") ? "PDF…" : "Формируем PDF…")
        : (button.classList.contains("mobile-pdf-button") ? "PDF" : "Скачать PDF-бланк");
    });
  }

  function pdfFileName() {
    const address = String(state.data.address || "Объект").trim();
    const safe = `${state.draftId} — ${TYPE_META[state.data.type].name} — ${address}`
      .replace(/[\\/:*?"<>|]/g, "-")
      .replace(/\s+/g, " ")
      .slice(0, 150);
    return `${safe}.pdf`;
  }

  async function downloadPdf() {
    if (state.pdfBusy || !validateBeforeSubmit()) return;
    if (!window.PDFGEN) {
      showToast("Генератор PDF не загрузился. Обновите страницу и попробуйте снова", "info");
      return;
    }
    state.pdfBusy = true;
    updatePdfButtons();
    showToast("Формируем PDF-бланк…", "loader-circle");
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    try {
      const order = exportPdfOrder();
      const pages = await window.PDFGEN.buildPages(order);
      if (!pages.length) throw new Error("No PDF pages");
      const blob = window.PDFGEN.makePdf(pages, order.address, clone(state.data));
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = pdfFileName();
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      showToast(`PDF-бланк скачан: ${pages.length} ${pages.length === 1 ? "страница" : pages.length < 5 ? "страницы" : "страниц"}`, "file-check-2");
    } catch (_) {
      showToast("Не удалось сформировать PDF. Проверьте данные и попробуйте снова", "info");
    } finally {
      state.pdfBusy = false;
      updatePdfButtons();
    }
  }

  function submitMeasurement() {
    if (!validateBeforeSubmit()) return;
    const id = state.draftId;
    const request = { id, owner: "Алексей Петров", date: "Только что", status: state.demoOffline ? "Ожидает синхронизации" : "Синхронизировано", data: clone(state.data) };
    if (state.demoOffline || !navigator.onLine) {
      const existing = state.queue.findIndex(item => item.id === id);
      if (existing >= 0) state.queue[existing] = request; else state.queue.unshift(request);
      persist();
      updateHeader();
      updateConnectivity();
      openDialog("success", "Офлайн-режим", "Замер сохранён в очередь", `<div class="success-state"><span class="success-icon"><i data-lucide="hard-drive"></i></span><h3>Данные останутся на устройстве</h3><p>Когда связь восстановится, синхронизируйте очередь. До этого заявка будет отмечена статусом «В очереди».</p><div class="success-details"><span>Номер заявки</span><strong>${id}</strong></div><div class="success-actions"><button class="button button-secondary" type="button" data-dialog-close>Продолжить</button><button class="button button-primary" type="button" data-action="requests">Открыть заявки</button></div></div>`);
    } else {
      const existing = state.requests.findIndex(item => item.id === id);
      if (existing >= 0) state.requests[existing] = request; else state.requests.unshift(request);
      state.queue = state.queue.filter(item => item.id !== id);
      persist();
      updateHeader();
      updateSummary();
      openDialog("success", "Демонстрация отправки", "Замер готов для общей базы", `<div class="success-state"><span class="success-icon"><i data-lucide="check"></i></span><h3>Заявка ${id} создана</h3><p>В рабочей версии она появится у руководителя и в списке ваших замеров. В этом макете запись добавлена только в локальный демонстрационный список.</p><div class="success-details"><span>Объект</span><strong>${esc(state.data.address)}</strong></div><div class="success-actions"><button class="button button-secondary" type="button" data-action="new">Новый замер</button><button class="button button-primary" type="button" data-action="requests">Открыть заявки</button></div></div>`);
    }
  }

  function syncQueue() {
    if (state.demoOffline || !navigator.onLine) {
      showToast("Нет связи. Очередь останется на устройстве", "cloud-off");
      return;
    }
    if (!state.queue.length) {
      showToast("Все заявки уже синхронизированы");
      return;
    }
    const count = state.queue.length;
    const synced = state.queue.map(item => ({ ...item, status: "Синхронизировано", date: "Только что" }));
    synced.forEach(request => {
      const index = state.requests.findIndex(item => item.id === request.id);
      if (index >= 0) state.requests[index] = request; else state.requests.unshift(request);
    });
    state.queue = [];
    persist();
    updateHeader();
    updateConnectivity();
    if (state.dialogView === "requests") showRequests();
    showToast(`Синхронизировано заявок: ${count}`, "refresh-cw");
  }

  function updateCalculations() {
    if (state.data.type === "door") {
      const calculations = $$("#type-fields .calculation");
      const door = state.data.door;
      if (calculations[0]) calculations[0].textContent = door.doorH && door.doorW ? `Размер двери: ${Math.max(0, Number(door.doorH) - 20)} × ${Math.max(0, Number(door.doorW) - 40)} мм` : "Размер двери рассчитается автоматически";
      if (calculations[1]) calculations[1].textContent = door.hatchH && door.hatchW ? `Размер люка: ${Math.max(0, Number(door.hatchH) - 10)} × ${Math.max(0, Number(door.hatchW) - 10)} мм · наличник со всех сторон` : "Размер люка рассчитается автоматически";
    } else if (state.data.type === "window") {
      $$(".window-item").forEach((element, index) => {
        const item = state.data.window.items[index], calculation = $(".calculation", element);
        if (calculation) calculation.textContent = item.h && item.w ? `Размер окна: ${Math.max(0, Number(item.h) - 20)} × ${Math.max(0, Number(item.w) - 40)} мм` : "Размер окна рассчитается автоматически";
      });
    }
  }

  document.addEventListener("click", event => {
    const target = event.target;
    const schemeButton = target.closest("[data-scheme]");
    if (schemeButton) {
      state.data.frame.scheme = schemeButton.dataset.scheme;
      renderTypeFields();
      touch();
      return;
    }
    const typeButton = target.closest("[data-type]");
    if (typeButton) {
      state.data.type = typeButton.dataset.type;
      renderTypeFields();
      clearErrors();
      touch();
      return;
    }

    const stepButton = target.closest("[data-step]");
    if (stepButton) {
      const key = stepButton.closest("[data-stepper]").dataset.stepper;
      const next = Math.max(1, Math.min(30, (Number(state.data[key]) || 0) + Number(stepButton.dataset.step)));
      state.data[key] = next;
      document.getElementById(key).value = next;
      if (key === "stops") { ensureFloors(); renderTypeFields(); }
      touch();
      return;
    }

    const toggle = target.closest("[data-toggle]");
    if (toggle) {
      const path = toggle.dataset.toggle;
      const enabled = !getPath(state.data, path);
      setPath(state.data, path, enabled);
      if (enabled && path === "frame.thresholdsOn" && !state.data.frame.thresholds.length) state.data.frame.thresholds.push(blankThreshold());
      if (enabled && path === "frame.nashchelnikOn" && !state.data.frame.nashchelnik.length) state.data.frame.nashchelnik.push(blankNashchelnik());
      if (enabled && path === "frame.bortikiOn") {
        if (!state.data.frame.cable.speed_limiter) state.data.frame.cable.speed_limiter = blankBortik();
        if (!state.data.frame.cable.main_drive) state.data.frame.cable.main_drive = blankBortik();
      }
      renderTypeFields();
      clearErrors();
      touch();
      $(`[data-toggle="${path}"]`)?.focus({ preventScroll: true });
      const extraKind = { "frame.thresholdsOn": "thresholds", "frame.nashchelnikOn": "nashchelnik", "frame.bortikiOn": "bortiki" }[path];
      if (enabled && extraKind) showExtraDialog(extraKind);
      return;
    }

    const extraOpen = target.closest("[data-extra-open]");
    if (extraOpen) { showExtraDialog(extraOpen.dataset.extraOpen); return; }

    const displaySelect = target.closest("[data-display-select]");
    if (displaySelect) {
      const count = Math.max(1, Math.min(30, Number(state.data.stops) || 1));
      state.displayFloorDraft = displaySelect.dataset.displaySelect === "all" ? Array.from({ length: count }, (_, index) => index + 1) : [];
      refreshDisplayFloorDialog();
      return;
    }

    const templateButton = target.closest("[data-template]");
    if (templateButton) {
      const template = templates.find(item => item.id === templateButton.dataset.template);
      if (!template) return;
      const data = clone(template.data);
      data.address = state.data.address;
      data.contact = state.data.contact;
      data.comment = state.data.comment;
      applyData(data, `Шаблон «${template.title}» применён`);
      return;
    }

    const copyButton = target.closest("[data-copy-request]");
    if (copyButton) {
      const request = [...state.requests, ...state.queue].find(item => item.id === copyButton.dataset.copyRequest);
      if (request) applyData(request.data, `Заявка ${request.id} скопирована в новый черновик`);
      return;
    }

    const requestButton = target.closest("[data-request]");
    if (requestButton) { showRequest(requestButton.dataset.request); return; }

    const roleButton = target.closest("[data-role]");
    if (roleButton) {
      state.role = roleButton.dataset.role;
      persist();
      updateHeader();
      closeDialog();
      showToast(state.role === "manager" ? "Режим руководителя: доступны все заявки команды" : "Режим замерщика: видны только ваши заявки", "users");
      return;
    }

    const extraAdd = target.closest("[data-extra-add]");
    if (extraAdd) {
      const kind = extraAdd.dataset.extraAdd;
      if (kind === "thresholds") state.data.frame.thresholds.push(blankThreshold());
      else if (kind === "nashchelnik") state.data.frame.nashchelnik.push(blankNashchelnik());
      else if (["speed_limiter", "main_drive"].includes(kind)) state.data.frame.cable[kind] = blankBortik();
      renderTypeFields();
      touch();
      const dialogKind = ["speed_limiter", "main_drive"].includes(kind) ? "bortiki" : kind;
      if (state.dialogView === `extra-${dialogKind}`) showExtraDialog(dialogKind);
      showToast("Раздел добавлен — заполните размеры и количество", "plus");
      return;
    }

    const extraRemove = target.closest("[data-extra-remove]");
    if (extraRemove) {
      const kind = extraRemove.dataset.extraRemove;
      if (kind === "thresholds" || kind === "nashchelnik") state.data.frame[kind].splice(Number(extraRemove.dataset.index) || 0, 1);
      else if (["speed_limiter", "main_drive"].includes(kind)) state.data.frame.cable[kind] = null;
      renderTypeFields();
      touch();
      const dialogKind = ["speed_limiter", "main_drive"].includes(kind) ? "bortiki" : kind;
      if (state.dialogView === `extra-${dialogKind}`) showExtraDialog(dialogKind);
      showToast("Раздел удалён из заявки", "trash-2");
      return;
    }

    const windowCopy = target.closest("[data-window-copy]");
    if (windowCopy) {
      const index = Number(windowCopy.dataset.windowCopy);
      const copy = { ...clone(state.data.window.items[index]), id: ++state.nextWindowId };
      state.data.window.items.splice(index + 1, 0, copy);
      renderTypeFields();
      touch();
      showToast("Окно продублировано вместе с размерами", "copy");
      return;
    }

    const windowRemove = target.closest("[data-window-remove]");
    if (windowRemove) {
      state.data.window.items.splice(Number(windowRemove.dataset.windowRemove), 1);
      renderTypeFields();
      touch();
      showToast("Позиция удалена", "trash-2");
      return;
    }

    if (target.closest("[data-dialog-close]")) { closeDialog(); return; }

    const actionButton = target.closest("[data-action]");
    if (!actionButton) return;
    const action = actionButton.dataset.action;
    if (action === "templates") showTemplates();
    else if (action === "display-floors") showDisplayFloors();
    else if (action === "apply-display-floors") applyDisplayFloors();
    else if (["frame-guide", "door-guide", "hatch-guide", "window-guide"].includes(action)) showDrawingGuide(action.replace("-guide", ""), Number(actionButton.dataset.index) || 0);
    else if (action === "copy") showCopy();
    else if (action === "requests") showRequests();
    else if (action === "new" || action === "reset") showResetConfirm();
    else if (action === "confirm-reset") applyData(makeData(false), "Новый пустой черновик создан");
    else if (action === "save") { clearTimeout(state.saveTimer); persist(); updateConnectivity(); showToast(state.demoOffline ? "Черновик сохранён на устройстве" : "Черновик сохранён", "save"); }
    else if (action === "submit") submitMeasurement();
    else if (action === "pdf") downloadPdf();
    else if (action === "sync") syncQueue();
    else if (action === "add-window") {
      state.data.window.items.push({ id: ++state.nextWindowId, kind: "Поворотное", h: "", w: "", qty: "1", hinge: "Петли справа", ebb: false, ebbL: "", ebbW: "" });
      renderTypeFields();
      touch();
      $$(".window-item").at(-1)?.scrollIntoView({ behavior: "smooth", block: "center" });
    } else if (action === "copy-floor") {
      const first = clone(state.data.frame.floors[0]);
      state.data.frame.floors = state.data.frame.floors.map(() => clone(first));
      renderTypeFields();
      touch();
      showToast("Размеры 1-го этажа скопированы на все этажи", "copy-plus");
    }
  });

  document.addEventListener("change", event => {
    const input = event.target.closest("[data-display-floor]");
    if (!input) return;
    const floor = Number(input.dataset.displayFloor);
    const selected = new Set(state.displayFloorDraft || []);
    if (input.checked) selected.add(floor); else selected.delete(floor);
    state.displayFloorDraft = [...selected].sort((a, b) => a - b);
    refreshDisplayFloorDialog();
  });

  $("#dialog-body").addEventListener("input", event => {
    const input = event.target;
    if (!input.matches("[data-bind]")) return;
    setPath(state.data, input.dataset.bind, input.value);
    input.classList.remove("input-error");
    input.closest(".field")?.classList.remove("field-error");
    touch();
  });

  $("#measure-form").addEventListener("input", event => {
    const input = event.target;
    if (input.matches("[data-bind]")) {
      const value = input.type === "checkbox" ? input.checked : input.value;
      setPath(state.data, input.dataset.bind, value);
      input.classList.remove("input-error");
      input.closest(".field")?.classList.remove("field-error");
      updateCalculations();
      touch();
    } else if (["address", "contact", "entrances", "stops", "comment"].includes(input.id)) {
      state.data[input.id] = input.id === "entrances" || input.id === "stops" ? input.value.replace(/[^0-9]/g, "").slice(0, 2) : input.value;
      if (input.value !== state.data[input.id]) input.value = state.data[input.id];
      if (input.id === "stops") renderTypeFields();
      input.classList.remove("input-error");
      input.closest(".field")?.classList.remove("field-error");
      touch();
    }
  });

  $("#measure-form").addEventListener("change", event => {
    if (event.target.id === "stops") {
      if (!Number(state.data.stops)) state.data.stops = 1;
      event.target.value = state.data.stops;
      ensureFloors();
      touch();
    }
    if (event.target.matches('select[data-bind], input[type="checkbox"][data-bind]')) {
      const path = event.target.dataset.bind;
      setPath(state.data, path, event.target.type === "checkbox" ? event.target.checked : event.target.value);
      if (path === "frame.buttonAll" || path === "door.hinge" || /^door\.casing/.test(path) || /^window\.items\.\d+\.(kind|hinge)$/.test(path)) renderTypeFields();
      touch();
    }
  });

  $("#measure-form").addEventListener("submit", event => event.preventDefault());
  $("#connection-button").addEventListener("click", () => {
    state.demoOffline = !state.demoOffline;
    updateConnectivity();
    showToast(state.demoOffline ? "Офлайн-сценарий включён: данные останутся на устройстве" : state.queue.length ? `Связь восстановлена. В очереди: ${state.queue.length}` : "Связь восстановлена", state.demoOffline ? "cloud-off" : "wifi");
  });

  function showRoleDialog() {
    openDialog("role", "Демонстрация прав", "Роль в макете", `<p class="dialog-description">Переключите роль, чтобы проверить, как меняется список заявок и доступ к общей базе.</p><div class="role-options"><button class="role-option ${state.role === "surveyor" ? "selected" : ""}" type="button" data-role="surveyor"><span class="role-radio"></span><span><strong>Замерщик</strong><small>Видит и повторяет только свои заявки. Может работать офлайн.</small></span><span class="avatar">АП</span></button><button class="role-option ${state.role === "manager" ? "selected" : ""}" type="button" data-role="manager"><span class="role-radio"></span><span><strong>Руководитель</strong><small>Видит заявки всей команды, исполнителей и статусы синхронизации.</small></span><span class="avatar">ИС</span></button></div>`);
  }
  $("#profile-button").addEventListener("click", showRoleDialog);
  $("#sidebar-role-button").addEventListener("click", showRoleDialog);
  $("#toast-close").addEventListener("click", () => $("#toast").classList.remove("visible"));
  $("#app-dialog").addEventListener("click", event => { if (event.target === event.currentTarget) closeDialog(); });
  $("#app-dialog").addEventListener("close", () => { state.dialogView = null; });
  window.addEventListener("pagehide", persist);
  window.addEventListener("online", () => { updateConnectivity(); showToast("Подключение к сети восстановлено", "wifi"); });
  window.addEventListener("offline", () => { updateConnectivity(); showToast("Сеть недоступна. Черновики сохраняются локально", "cloud-off"); });

  renderAll();
  persist();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
  }
})();
